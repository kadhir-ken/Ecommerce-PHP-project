<?php
require_once "config.php";
session_start(); // Start the session to manage cart items

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = $_POST['id'];

    // Prepare and execute the delete statement
    $stmt = $link->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);

    if ($stmt->execute()) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $link->error;
    }

    $stmt->close();
    $link->close();
    exit();
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
  
    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount']=$cartItemCount; 
    $stmt->close();
}

// Filter products by country and category
$countryFilter = isset($_POST['country']) ? $_POST['country'] : '';
$categoryFilter = isset($_POST['category']) ? $_POST['category'] : '';

// Retrieve filtered products based on the selected country and category
$sql = "SELECT * FROM products WHERE 1=1";
if (!empty($countryFilter)) {
    $sql .= " AND country = ?";
}
if (!empty($categoryFilter)) {
    $sql .= " AND category = ?";
}

$stmt = $link->prepare($sql);

if (!empty($countryFilter) && !empty($categoryFilter)) {
    $stmt->bind_param("ss", $countryFilter, $categoryFilter);
} elseif (!empty($countryFilter)) {
    $stmt->bind_param("s", $countryFilter);
} elseif (!empty($categoryFilter)) {
    $stmt->bind_param("s", $categoryFilter);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
        a{
            text-decoration:none;
        }

        #filter-section {
            position: relative;
            left: 20%;
        }
        form {
            justify-content: center;
            height: 130px;
            max-width: 300px;
            margin: 20px auto;
            padding: 30px;
            position: relative;
            left: -500px;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        form h4 {
            margin-bottom: 15px;
            font-size: 20px;
            text-align: center;
            color: #333;
        }

        form input[type="text"], form textarea, form input[type="file"] {
            width: calc(100% - 24px);
            margin: 8px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            background-color: #f5f5f5;
        }

        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            margin-top: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        form textarea {
            height: 100px;
            resize: none;
        }

        .cart-count {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 14px;
            vertical-align: top;
            margin-left: -10px;
        }

        .china {
            width: 200px;
        }

        li {
            text-decoration: none;
            display: inline-flex;
            flex-direction: row;
            padding: 15px;
        }

        a img {
            transition: transform 0.3s ease;
            display: block;
            width: 100%;
        }

        a img:hover {
            transform: scale(1.1);
        }

        select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border: 1px solid #ccc;
            border-radius: 4px;
            padding: 10px 15px;
            font-size: 16px;
            background-color: #fff;
            background-image: url('path/to/arrow-icon.svg');
            background-position: right 10px center;
            background-repeat: no-repeat;
            background-size: 16px 16px;
            width: 100%;
            box-sizing: border-box;
            transition: border-color 0.3s ease;
        }

        select:focus {
            border-color: #007bff;
            outline: none;
        }

        .select-container {
            position: relative;
            display: inline-block;
        }

        .select-container::after {
            content: '';
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            width: 0;
            height: 0;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-top: 8px solid #333;
        }

        /* Style for the filters row */
        .filters-row {
            display: flex;
            gap: 20px;
        }

        .filters-row select {
            flex: 1;
        }
    </style>
</head>
<body>
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
        <div>
            <ul id="navbar-1">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a class="active" href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>
            </ul>
            <ul id="navbar"> 
                <a href="#" id="close"><i class="fa fa-times"></i></a>
                <a href="#" id="home-close"><i class="fa fa-times"></i></a>
                <div id="row-1">
                    <div>
                        <div id="user-info">
                            <?php if (isset($_SESSION['user_name'])): ?>
                                <p>Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php 
                        if (isset($_SESSION['user_name'])){
                            echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                        } else {
                            echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                            echo "<br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";
                            echo "<br><a id='help' href='#'>help?</a>";
                        } ?>
                    </div>
                </div>
            </ul>
            <!-- Mobile Navigation -->
            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">Help?</a>
            </ul>
        </div>
    </section>
    
    <section id="filter-section">
        <form method="post">
            <h4>Filter Products</h4>
            <div class="filters-row">
                <div class="select-container">
                    <select name="country">
                        <option value="">Select Country</option>
                        <!-- Populate with country options from your database -->
                        <option value="India">India</option>
                        <option value="China">China</option>
                        <option value="Vietnam">Vietnam</option>
                        <!-- Add more options as needed -->
                    </select>
                </div>
                <div class="select-container">
                    <select name="category">
                        <option value="">Select Category</option>
                        <!-- Populate with category options from your database -->
                        <option value="Electronics">Electronics</option>
                        <option value="Clothing">Clothing</option>
                        <option value="Furniture">Furniture</option>
                        <!-- Add more options as needed -->
                    </select>
                </div>
            </div>
            <input type="submit" value="Filter">
        </form>
    </section>

    <section id="product-list">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="product-card">
                <img src="<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                <p>Price: $<?php echo htmlspecialchars($row['price']); ?></p>
                <p>Country: <?php echo htmlspecialchars($row['country']); ?></p>
                <p>Category: <?php echo htmlspecialchars($row['category']); ?></p>
                <form method="post" action="shop.php">
                    <input type="hidden" name="action" value="delete">
                    <input type="hidden" name="id" value="<?php echo htmlspecialchars($row['id']); ?>">
                    <input type="submit" value="Delete">
                </form>
            </div>
        <?php endwhile; ?>
    </section>

    <section id="footer">
        <p>&copy; 2024 Three Dreams eCommerce Pvt. Ltd. All rights reserved.</p>
    </section>
</body>
</html>

<?php
$stmt->close();
$link->close();
?>
