<?php
require_once "config.php";

// Get product ID from URL
$product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

$sql = "SELECT * FROM products WHERE id = ?";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $product_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    echo "<h1>" . htmlspecialchars($row["name"]) . "</h1>";
    echo "<p>" . htmlspecialchars($row["description"]) . "</p>";
    echo "<p>Price: $" . htmlspecialchars($row["price"]) . "</p>";
    echo "<p>Category: " . htmlspecialchars($row["category"]) . "</p>";
    echo "<p>Reviews: " . htmlspecialchars($row["reviews"]) . "</p>";
    echo "<img src='" . htmlspecialchars($row["image"]) . "' alt='" . htmlspecialchars($row["name"]) . "' style='width:400px;'><br>";
} else {
    echo "<p>Product not found.</p>";
}

$stmt->close();
$link->close();
?>
