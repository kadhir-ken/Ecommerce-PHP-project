<?php
require_once "config.php";
session_start(); // Start the session to manage cart items

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = $_POST['id'];

    // Prepare and execute the delete statement
    $stmt = $link->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);

    if ($stmt->execute()) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $link->error;
    }

    $stmt->close();
    $link->close();
    exit();
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
  
    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount'] = $cartItemCount; 
    $stmt->close();
}

// Handle filters: country, category, and search
$countryFilter = isset($_POST['country']) ? $_POST['country'] : '';
$categoryFilter = isset($_POST['category']) ? $_POST['category'] : '';
$searchQuery = isset($_POST['search']) ? '%' . $_POST['search'] . '%' : '';

// SQL query for filtering
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];
$types = '';

if (!empty($countryFilter)) {
    $sql .= " AND country = ?";
    $params[] = $countryFilter;
    $types .= 's';
}
if (!empty($categoryFilter)) {
    $sql .= " AND category = ?";
    $params[] = $categoryFilter;
    $types .= 's';
}
if (!empty($searchQuery)) {
    $sql .= " AND name LIKE ?";
    $params[] = $searchQuery;
    $types .= 's';
}

$stmt = $link->prepare($sql);

if ($stmt === false) {
    die("Error preparing the SQL statement: " . $link->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
        a {
            text-decoration: none;
        }

        #filter-section {
            position: relative;
            left: 20%;
        }

        form {
            justify-content: center;
            height: 230px;
            width: 600px;
            max-width: 800px;
            margin: 20px auto;
            padding: 30px 20px;
            background-color: lightblue;
            border: 2px solid black;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        form h4 {
            margin-bottom: 15px;
            font-size: 20px;
            text-align: center;
            color: #333;
        }

        form input[type="text"], form select {
            width: 100%;
            margin: 8px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            background-color: #f5f5f5;
        }

        form input[type="submit"] {
            width: 48%;
            padding: 10px;
            margin-top: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        form input[type="submit"]:hover {
            background-color: #0056b3;
        }

        .clear-btn {
            background-color: #dc3545;
        }

        .clear-btn:hover {
            background-color: #c82333;
        }

        .cart-count {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 14px;
            vertical-align: top;
            margin-left: -10px;
        }
    </style>
</head>
<body>
    <section id="header">
        <!-- Header content -->
    </section>

    <section id="filter-section">
        <form method="POST">
            <h4>Search and Filter</h4>
            <label for="search">Search Products:</label>
            <input type="text" name="search" id="search" value="<?php echo isset($_POST['search']) ? $_POST['search'] : ''; ?>" placeholder="Search by product name">

            <label for="category">Select Category:</label>
            <select name="category" id="category">
                <option value="">All Categories</option>
                <option value="Household Items" <?php echo $categoryFilter == 'Household Items' ? 'selected' : ''; ?>>Household Items</option>
                <option value="Electronics" <?php echo $categoryFilter == 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                <option value="Clothes" <?php echo $categoryFilter == 'Clothes' ? 'selected' : ''; ?>>Clothes</option>
                <option value="Fashion Accessories" <?php echo $categoryFilter == 'Fashion Accessories' ? 'selected' : ''; ?>>Fashion Accessories</option>
                <option value="Stationery" <?php echo $categoryFilter == 'Stationery' ? 'selected' : ''; ?>>Stationery</option>
                <option value="Skin and Hair care products" <?php echo $categoryFilter == 'Skin and Hair care products' ? 'selected' : ''; ?>>Skin and Hair care products</option>
                <!-- Add more categories as needed -->
            </select><br>

            <input type="submit" value="Apply Filter">
            <input type="submit" name="clear_filter" value="Clear Filter" class="clear-btn">
        </form>

        <?php
        // Handle clear filter functionality
        if (isset($_POST['clear_filter'])) {
            $countryFilter = '';
            $categoryFilter = '';
            $searchQuery = '';
            header("Location: " . $_SERVER['PHP_SELF']); // Refresh page to reset filters
            exit();
        }
        ?>

        <div class="product-container">
            <!-- Display filtered products here -->
            <?php while ($product = $result->fetch_assoc()): ?>
                <div class="product-item">
                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                    <p>Category: <?php echo htmlspecialchars($product['category']); ?></p>
                    <p>Country: <?php echo htmlspecialchars($product['country']); ?></p>
                </div>
            <?php endwhile; ?>
        </div>
    </section>
</body>
</html>
