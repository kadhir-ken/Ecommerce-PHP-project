<?php
require_once "config.php";
session_start(); // Start the session to manage cart items

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = $_POST['id'];

    // Prepare and execute the delete statement
    $stmt = $link->prepare("DELETE FROM products WHERE id = ?");
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $link->error);
    }
    $stmt->bind_param("i", $productId);

    if ($stmt->execute()) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $link->error;
    }

    $stmt->close();
    $link->close();
    exit();
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    if ($stmt === false) {
        die("Error preparing the SQL statement: " . $link->error);
    }
    $stmt->bind_param("i", $userId);
    $stmt->execute();
  
    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount'] = $cartItemCount;
    $stmt->close();
}

// Filter products by country, category, or search term
$countryFilter = isset($_POST['country']) ? $_POST['country'] : '';
$categoryFilter = isset($_POST['category']) ? $_POST['category'] : '';
$searchQuery = isset($_POST['search']) ? '%' . $_POST['search'] . '%' : '';

// Retrieve filtered products based on the selected filters and search query
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];
$types = '';

if (!empty($countryFilter)) {
    $sql .= " AND country = ?";
    $params[] = $countryFilter;
    $types .= 's';
}
if (!empty($categoryFilter)) {
    $sql .= " AND category = ?";
    $params[] = $categoryFilter;
    $types .= 's';
}
if (!empty($searchQuery)) {
    $sql .= " AND name LIKE ?";
    $params[] = $searchQuery;
    $types .= 's';
}

$stmt = $link->prepare($sql);

if ($stmt === false) {
    die("Error preparing the SQL statement: " . $link->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
        a { text-decoration: none; }
        #filter-section {
            position: relative;
            left: 20%;
        }
        form {
            justify-content: center;
            max-width: 300px;
            margin: 20px auto;
            padding: 30px;
            position: relative;
            background-color: #f9f9f9;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        form input[type="text"], form select {
            width: 100%;
            margin: 8px 0;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            background-color: #f5f5f5;
        }
        form input[type="submit"] {
            width: 100%;
            padding: 10px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }
        .cart-count {
            background-color: red;
            color: white;
            border-radius: 50%;
            padding: 2px 8px;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>Three Dreams eCommerce Pvt. Ltd</h4></div>
        <ul id="navbar">
            <li><a href="index.php">Home</a></li>
            <li><a href="about.php">About</a></li>
            <li><a href="services.php">Services</a></li>
            <li><a class="active" href="shop.php">Shop</a></li>
            <li><a href="contact.php">Contact</a></li>
        </ul>
        <div id="home-nav">
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php echo $_SESSION['cartcount'] ?? 0; ?></span>
            </a>
        </div>
    </section>

    <section id="page-header"> </section>

    <section id="product1" class="section-p1">
        <div class="pro-container">
            <section id="filter-section">
                <!-- Filter and Search Form -->
                <form method="post" id="filter-form">
                    <label for="search">Search Products:</label>
                    <input type="text" name="search" id="search" placeholder="Search by product name">
                    
                    <label for="category">Select Category:</label>
                    <select name="category" id="category">
                        <option value="">All Categories</option>
                        <option value="Household Items" <?php echo $categoryFilter == 'Household Items' ? 'selected' : ''; ?>>Household Items</option>
                        <option value="Electronics" <?php echo $categoryFilter == 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                        <option value="Clothes" <?php echo $categoryFilter == 'Clothes' ? 'selected' : ''; ?>>Clothes</option>
                        <!-- Add more categories as needed -->
                    </select>
                    
                    <label for="country">Select Country:</label>
                    <select name="country" id="country">
                        <option value="">All Countries</option>
                        <option value="India" <?php echo $countryFilter == 'India' ? 'selected' : ''; ?>>India</option>
                        <option value="China" <?php echo $countryFilter == 'China' ? 'selected' : ''; ?>>China</option>
                        <option value="Vietnam" <?php echo $countryFilter == 'Vietnam' ? 'selected' : ''; ?>>Vietnam</option>
                    </select>
                    
                    <input type="submit" value="Filter">
                </form>
            </section>

            <!-- Display Products -->
            <div class="product-list">
                <?php while ($product = $result->fetch_assoc()): ?>
                    <div class="product-item">
                        <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p><?php echo htmlspecialchars($product['description']); ?></p>
                        <p>Price: <?php echo htmlspecialchars($product['price']); ?></p>
                        <form method="post">
                            <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit">Delete</button>
                        </form>
                    </div>
                <?php endwhile; ?>
            </div>
        </div>
    </section>
</body>
</html>
