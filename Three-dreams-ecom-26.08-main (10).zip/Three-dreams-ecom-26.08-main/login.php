<?php
session_start();
require_once "config.php"; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($email) || empty($password)) {
        echo "Email and Password are required.";
        exit;
    }

    // Prepare SQL statement to prevent SQL injection
    $sql = "SELECT id, user_name, password FROM users1 WHERE email = ? or user_name='$email'";
    if ($stmt = $link->prepare($sql)) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($id, $name, $hashed_password);
            $stmt->fetch();

            // Verify password
            if (password_verify($password, $hashed_password)) {
                // Password is correct, start session and redirect
                $_SESSION['user_id'] = $id;
                $_SESSION['user_name'] = $name;
                $_SESSION['user_email'] = $email;

                header("Location: index.php"); // Redirect to the homepage
                exit;
            } else {
                echo "Invalid password.";
            }
        } else {
            echo "No account found with that email.";
        }

        $stmt->close();
    } else {
        echo "Error preparing the SQL statement: " . $link->error;
        error_log("Error preparing SQL statement: " . $link->error);
    }

    $link->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd Login Form</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" type="text/css" href="login.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
</head>
<body>
<section id="page-header">
    <header>


    </header>
   </section>
            <section class="container">    <div class="div-box">
          
          <div class="box1" ><img src="images/logo & title/new logo.png" class="logo" alt="logo">
          </div>
         
         <div class="box2"><div class="logo-name"><h1>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h1><h3>𝑩𝒓𝒊𝒅𝒈𝒊𝒏𝒈 𝑩𝒐𝒓𝒅𝒆𝒓𝒔 𝒂𝒏𝒅 𝑺𝒐𝒖𝒓𝒄𝒊𝒏𝒈 𝑺𝒖𝒄𝒄𝒆𝒔𝒔</h3></div>
       
        </div> 
      </div>
      
            <div class="box">
                <h2>Login Here</h2>
              
                <form name ="my-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                    <div class="user-details">
                        <div class="input-box">
                            <p class="details">Email or Username</p>
                            <input type="text" name="email" placeholder="Enter Email" required>
                            <span class="text-danger"></span>
                        </div>
                        <div class="input-box">
                            <br>
                            <p class="details">Password</p>
                            <input type="password" name="password" placeholder="Enter Password" required>
                            <span class="text-danger"></span>
                             <div id="errorBox"></div>
</div>
                    </div>
                    <button type="submit" id="sub-btn" value="Login" >Login</button><br>
                    <a href="forgotpwd.php"><center>Forgot password?</center></a>
                    <center><h6>Don't have an account?</h6></center>
                    <center><a href="register.php">Register for a new account?</a></center>
                </form>
            </div>
        </div>
    </section>
</body></head>
</html>
