<?php
require_once "config.php"; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize inputs
    $full_name = isset($_POST['fullname']) ? trim($_POST['fullname']) : '';
    $user_name = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email = isset($_POST['Email']) ? trim($_POST['Email']) : '';
    $phone_number = isset($_POST['phone']) ? trim($_POST['phone']) : '';
    $country_code = isset($_POST['country_code']) ? trim($_POST['country_code']) : '';
    $password = isset($_POST['pwd']) ? trim($_POST['pwd']) : '';
    $confirm_password = isset($_POST['confpwd']) ? trim($_POST['confpwd']) : '';
    $date_of_birth = isset($_POST['DOB']) ? trim($_POST['DOB']) : '';
    $gender = isset($_POST['gender']) ? trim($_POST['gender']) : '';

    // Check if passwords match
    if ($password !== $confirm_password) {
        echo "Passwords do not match.";
        exit;
    }

    // Check if email already exists
    $email_check_sql = "SELECT email FROM users1 WHERE email = ?";
    if ($email_check_stmt = $link->prepare($email_check_sql)) {
        $email_check_stmt->bind_param("s", $email);
        $email_check_stmt->execute();
        $email_check_stmt->store_result();

        if ($email_check_stmt->num_rows > 0) {
            echo "Email already exists.";
            $email_check_stmt->close();
            exit;
        }

        $email_check_stmt->close();
    } else {
        echo "Failed to prepare email check statement.";
        error_log("Error preparing email check SQL statement: " . $link->error);
        exit;
    }

    // Hash the password using a strong algorithm (e.g., bcrypt)
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);

    // Prepare an insert statement
    $sql = "INSERT INTO users1 (full_name, user_name, email, phone_number, country_code, password, date_of_birth, gender,created_at) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?,CURRENT_TIMESTAMP)";

    if ($stmt = $link->prepare($sql)) {
        // Bind parameters
        $stmt->bind_param("ssssssss", $full_name, $user_name, $email, $phone_number, $country_code, $hashed_password, $date_of_birth, $gender);

        if ($stmt->execute()) {
            echo "Registration successful! You can now login.";
        } else {
            echo "Something went wrong during registration. Please try again later.";
            error_log("Error in registration: " . $stmt->error);
        }

        $stmt->close();
    } else {
        echo "Failed to prepare the SQL statement: " . $link->error;
        error_log("Error preparing SQL statement: " . $link->error);
    }

    $link->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd Register Form</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" type="text/css" href="register.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/css/intlTelInput.min.css">


</head>
<body>
<section id="page-header">
    <header>
    </header>
</section>
   
<section class="container">
    <div class="div-box">
        <div class="box1">
            <img src="images/logo & title/new logo.png" class="logo" alt="logo">
        </div>
        <div class="box2">
            <div class="logo-name">
                <h1>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h1>
                <h3>𝑩𝒓𝒊𝒅𝒈𝒊𝒏𝒈 𝑩𝒐𝒓𝒅𝒆𝒓𝒔 𝒂𝒏𝒅 𝑺𝒐𝒖𝒓𝒄𝒊𝒏𝒈 𝑺𝒖𝒄𝒄𝒆𝒔𝒔</h3>
            </div>
        </div> 
    </div>
    
    <div class="box">
        <div class="title">
            <center><h2>Register Here</h2></center>
        </div>

        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
            <div class="user-details">
                <div class="input-box">
                    <span class="details">Full Name</span>
                    <input type="text" name="fullname" placeholder="Enter Full Name" required>
                </div>
                <div class="input-box">
                    <span class="details">User Name</span>
                    <input type="text" name="username" placeholder="Enter User Name" required>
                </div>
                <div class="input-box">
                    <span class="details">Email</span>
                    <input type="text" name="Email" placeholder="Enter Email" required>
                </div>
                <div class="input-box">
                    <span class="details">Phone Number</span>
                    <input type="tel" id="phoneInput" name="phone" placeholder="Enter phone number">
                </div>
                <div class="input-box">
                    <span class="details">Password</span>
                    <input type="password" name="pwd" placeholder="Enter password" required>
                </div>
                <div class="input-box">
                    <span class="details">Confirm Password</span>
                    <input type="text" name="confpwd" placeholder="Confirm Password" required>
                </div>
                <div class="input-box">
                    <span class="details">Date of Birth</span>
                    <input type="date" name="DOB" placeholder="Enter Date of Birth" required>
                </div>
            </div>
            <div>
                <div class="gender-details">
                    <input type="radio" name="gender" id="dot-1" value="male">
                    <input type="radio" name="gender" id="dot-2" value="female">
                    <input type="radio" name="gender" id="dot-3" value="not want to specify">
                    <span class="gender-title">Gender</span>
                    <div class="category">
                        <label for="dot-1"> 
                            <span class="dot one"></span>
                            <span class="gender">Male</span>
                        </label>
                        <label for="dot-2">
                            <span class="dot two"></span>
                            <span class="gender">Female</span>
                        </label>
                        <label for="dot-3">
                            <span class="dot three"></span>
                            <span class="gender">Do not want to specify</span>
                        </label>
                    </div>
                </div>
                <input type="hidden" id="countryCode" name="country_code">
                <div class="button">
                    <button id="reg-btn" type="submit">Register</button>
                </div>
                <center>
                    <div class="btn-a"><a href="index.php">Existing user, login?</a></div>
                </center> 
            </div>
        </form>
    </div>
</section>

<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/intlTelInput.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js"></script>
<script>
    const phoneInput = document.querySelector("#phoneInput");
    const countryCodeInput = document.querySelector("#countryCode");

    // Initialize intlTelInput
    const iti = window.intlTelInput(phoneInput, {
        utilsScript: "https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.12/js/utils.min.js"
    });

    // Set initial country based on the user's location
    iti.promise.then(() => {
        const countryCode = iti.getSelectedCountryData().iso2;
        iti.setCountry(countryCode);
    });

    // Listen for the country change event
    phoneInput.addEventListener("countrychange", function() {
        const countryCode = iti.getSelectedCountryData().dialCode;
        countryCodeInput.value = countryCode;
    });

    phoneInput.addEventListener("blur", function() {
        const countryCode = iti.getSelectedCountryData().dialCode;
        countryCodeInput.value = countryCode;
    });
</script>
</body>
</html>