<?php
require_once "config.php";
session_start();

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get the user ID from session
$user_id = $_SESSION['user_id'];

// Fetch cart items for the user
$sql = "
    SELECT 
        c.id AS cart_id, 
        p.image, 
        p.name, 
        p.price, 
        c.quantity 
    FROM cart c
    JOIN products p ON c.product_id = p.id
    WHERE c.user_id = ?
";
$stmt = $link->prepare($sql);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$cart_items = $stmt->get_result();

// Handle removal of items
if (isset($_GET['remove'])) {
    $cart_id = intval($_GET['remove']);
    
    $delete_sql = "DELETE FROM cart WHERE id = ? AND user_id = ?";
    $delete_stmt = $link->prepare($delete_sql);
    $delete_stmt->bind_param("ii", $cart_id, $user_id);
    $delete_stmt->execute();
    
    header("Location: cart.php");
    exit;
}

// Calculate cart totals
$cart_total = 0;
$cart_items_array = [];

while ($item = $cart_items->fetch_assoc()) {
    $item['subtotal'] = $item['price'] * $item['quantity'];
    $cart_total += $item['subtotal'];
    $cart_items_array[] = $item;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cart | Three Dreams Ecommerce Pvt.Ltd</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
</head>
<body>
    
    <section id="header">
        <a href="#"><img src="E-commerce/ThreeDream logo2.jpg" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
        <div>
            <ul id="navbar-1">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a class="active" href="shop.html">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>
            </ul>
            <!-- Mobile Navigation -->
            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.html">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.php"><i class="fa fa-shopping-bag" ></i></a>
            <i id="bar" class="fas fa-outdent"></i> 
        </div>
    </section>

    <section id="page-header" class="about-header">
        <h2>#Cart</h2>
        <p>Add your coupon & Save up to 70%!</p>
    </section>

    <section id="cart" class="section-p1">
        <table width="70%">
            <thead>
                <tr>
                    <td>Remove</td>
                    <td>Image</td>
                    <td>Product</td>
                    <td>Price</td>
                    <td>Quantity</td>
                    <td>Subtotal</td>
                </tr>
            </thead>
            <tbody>
                <?php if (!empty($cart_items_array)): ?>
                    <?php foreach ($cart_items_array as $item): ?>
                        <tr>
                            <td><a href="cart.php?remove=<?php echo $item['cart_id']; ?>"><i class="far fa-times-circle"></i></a></td>
                            <td><img src="<?php echo htmlspecialchars($item['image']); ?>" class="cart-img" alt=""></td>
                            <td><?php echo htmlspecialchars($item['name']); ?></td>
                            <td>$<?php echo htmlspecialchars(number_format($item['price'], 2)); ?></td>
                            <td><input type="number" value="<?php echo htmlspecialchars($item['quantity']); ?>" readonly></td>
                            <td>$<?php echo htmlspecialchars(number_format($item['subtotal'], 2)); ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6">Your cart is empty.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </section>

    <section id="cart-add" class="section-p1">
        <div id="coupon">
            <h3>Apply Coupon</h3>
            <div>
                <input type="text" placeholder="Enter Your Coupon">
                <button class="normal">Apply</button>
            </div>
        </div>

        <div id="subtotal">
            <h3>Cart Totals</h3>
            <table>
                <tr>
                    <td>Cart Subtotal</td>
                    <td>$<?php echo htmlspecialchars(number_format($cart_total, 2)); ?></td>
                </tr>
                <tr>
                    <td>Shipping</td>
                    <td>Free</td>
                </tr>
                <tr>
                    <td><strong>Total</strong></td>
                    <td><strong>$<?php echo htmlspecialchars(number_format($cart_total, 2)); ?></strong></td>
                </tr>
            </table>
            <button class="normal">Proceed to checkout</button>
        </div>
    </section>

    <footer class="section-p1">
        <!-- Your footer content here -->
    </footer>

    <script src="index.js"></script>

</body>
</html>
