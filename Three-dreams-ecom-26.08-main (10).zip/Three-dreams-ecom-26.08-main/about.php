
<?php 
session_start();?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >Three Dreams eCommerce pvt.ltd</title>
    <link rel="web icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
   <style>
     .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }
   </style>
</head>
<body>
    
    <!-- <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="logoname"><h4><bold>Three Dreams E-commerce Pvt.Ltd</bold></h4></div>
       

        <div>
            <ul id="navbar-2">
             <li><a href="index.php">Home</a></li>
             <li><a class="active"  href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li>
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li>
            <li id="lg-bag"><a href="cart.html"><i class="fa fa-shopping-bag" ></i></a></li> 
             <a href="#" id="close"><i class="fa fa-times"></i></a>
            </ul>
        </div>
        <div id="mobile">
            <a href="cart.html"><i class="fa fa-shopping-bag" ></i></a>
            
                <i id="bar" class="fas fa-outdent"></i> 
        </div>

    </section> -->
  
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
       
        <div>
            <ul id="navbar-1">
                
                <li><a href="index.php">Home</a></li>
                <li><a class="active"  href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>

            </ul>


            <ul id="navbar"> 
             <!-- <li id="lg-bag"><a><i class="fa fa-shopping-bag" ></i></a></li> -->
             <!-- <li><a class="active" href="index.php">Home</a></li>
             <li><a href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li> 
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li> -->
             <a href="#" id="close"><i class="fa fa-times"></i></a>


             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
             <div id="row-1">
                 <div>
                 <div id="user-info">
            <?php if (isset($_SESSION['user_name'])): ?>
                <p > <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                
          
               
            <?php endif; ?>
        </div>
                    <?php 
                    if (isset($_SESSION['user_name'])){
                        echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                    }else{
                        echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                   echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

                echo "<br><a id='help' href='#'>help?</a>";
                    }?>
                </div>
             </div>

              
            </ul><br>

            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                

                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
                
            </ul>

        </div>
      
        <div id="home-nav"> 
        <a href="cart.php"> <?php
               
               if (isset($_SESSION['user_id']) && isset($_SESSION['cartcount'])) {
                   $cartItemCount=$_SESSION['cartcount'];
              echo "<i class='fa fa-shopping-bag'><span class='cart-count'> $cartItemCount
                    </span></i>";}?>
       </a>      
           <i id="home-bar" class="fas fa-outdent"></i>
          
        </div>
      
        <div id="mobile">
            <a href="#"><i class="fa fa-shopping-bag" ></i></a>
                <i id="bar" class="fas fa-outdent"></i>
               
        </div>

    </section>




    <section id="page-header" class="about-header">
       
       
    </section>


    <section id="about-head" class="section-p1">
        <img src="images/about/img1.jpg" alt="">
        <div>
            <!-- <h2>Who We Are?</h2>
            <p> Three Dreams Ecommerce Private Limited (TDEPL) is a Private Limited Indian Non-Government Company incorporated in India on 16 September 2023 ( nine months 19 days old ). Its registered office is in Chennai, Tamil Nadu, India.
               The Company's status is Active It's a company limited by shares with an authorized capital of Rs 10.00 Lakh and a paid-up capital of Rs 1.00 Lakh, as per the Ministry of Corporate Affairs (MCA) records.
            <br><h5>Our Mission</h5>
            Our mission is to make it easy to do business anywhere.  We do this by giving suppliers the tools necessary to reach a global audience for their products, and by helping buyers find products and suppliers quickly and efficiently.
            <br><br>
            <h5>Anytime, Anywhere</h5>
             As a platform, we continue to develop services to help businesses do more and discover new opportunities.Whether it’s sourcing from your mobile phone or contacting suppliers in their local language, turn to Three Dreams E-commerce pvt.ltd for all your global business needs.
         </p> -->
         <p>Welcome to Three Dreams, your trusted partner in sourcing products across the globe. We specialize
            in connecting businesses with high-quality products, facilitating seamless trade between India
            and the rest of the world. Whether you’re looking to source products from India to other
            countries or import goods from countries like China and Vietnam to India or other countries,
            we’ve got you covered.</p>   
        <h4>Why Choose Three Dreams?</h4><br>
            <h5>Global Reach:</h5>
                <p>Our extensive network spans multiple countries, ensuring you get the
            best products from the best sources.</p>
            <h5>Quality Assurance:</h5>
                <p> We prioritize quality at every step, from sourcing to delivery, so you
            can be confident in the products you receive.</p>
            <h5>Competitive Pricing:</h5>
                <p> Benefit from our strong supplier relationships to get competitive 
            prices without compromising on quality.</p>
            <h5>Expert Support:</h5> 
                <p>Our team of sourcing experts is dedicated to helping you navigate the
            complexities of international trade with ease.</p><br>
            
            <marquee bgcolor="#ccc" loop="-1" scrollamount="5" width="100%">THREE DREAMS E-COMMERCE PRIVATE LIMITED, CHENNAI ,INDIA.</marquee>

        </div>

    </section>

    <section id="about-app" class="section-p1">
         <h1>Download Our App</h1> 

    </section>

    <section id="feature" class="section-p1">
        <!-- <div class="fe-box">
           <img src="images/home/card img/fe img1.jpg" alt="shipping">
           <h6>Free Shipping</h6>
        </div> -->
        <div class="fe-box">
           <img src="images/home/card img/fe img2.jpg" alt="order">
           <h6>Online Order</h6>
        </div>
        <div class="fe-box">
           <img src="images/home/card img/fe img3.jpg" alt="money">
           <h6>Save Money</h6>
       </div>
       <div class="fe-box">
           <img src="images/home/card img/fe img4.jpg" alt="Promotions">
           <h6>Promotions</h6>
       </div>
       <div class="fe-box">
           <img src="images/home/card img/fe img5.jpg" alt="sell">
           <h6>Happy Sell</h6>
       </div>
       <div class="fe-box">
           <img src="images/home/card img/fe img6.jpg" alt="support">
           <h6>F24/7Support</h6>
       </div>

       
  </section>

  <!-- <section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Sign Up For Newsletters</h4>
        <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
    </div>
     <div class="form">
        <input type="text" placeholder="Your email address">
        <button class="normal">Sign Up</button>
     </div>
</section> -->

<footer class="section-p1">
    <div class="col">
      <div class="logo-icon"><img src="images/logo & title/ThreeDream logo.jpg" alt="logo img"  style="height:100px;width: 120px;">
      <h6>Three Dreams eCommerce pvt.ltd </h6></div><br>
      <h4>Contact</h4>
      <p><strong>Address:</strong> No #13/53 , Rams Apartment , 3rd Floor ,AshokNagar,Chennai-600 083,TamilNadu,India</p>
      <p><strong>Phone:</strong>  +91 9003472895</p>

   
     <div class="follow">
       <h4>Follow us</h4>
        <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <!-- <i class="fab fa-pinterest-p"></i>
            <i class="fab fa-youtube"></i> -->
        </div>
     </div>
  </div>

  <div class="col">
       <h4>About</h4>
       <a href="about.php">About Us</a>
       <a href="services.php">Services</a>
       <a href="shop.html">Shop</a>
       <a href="contact.php">Contact Us</a>
  </div>


  <div class="col">
      <h4>My Account</h4>
      <a href="#">Sign in</a>
      <a href="#">View Cart</a>
      <a href="#">My Wishlist</a>
      <a href="#">Track My Order</a>
      <a href="#">Help</a>
 </div>

  <!-- <div class="col install">
      <h4>Install App</h4>
      <p>From App Store or Google Play</p>
      <div class="row">
           <img src="images/logo & title/icon img17.jpg" alt="app store icon" style="height: 60px;width: 120px;"  >
          <img src="images/logo & title/icon img18.jpg" alt="" style="height: 60px; width: 120px;"> 
      </div>
      <p>Secure Payment Gateways</p>
       <img src="images/logo & title/pay img 1.jpg" alt="payment icon" style="height:80px; width:140px;">
  </div> -->

  <div class="copyright">
      <p>©2024, ThreeDreams E-commerce pvt.ltd etc- HTML CSS Ecommerce Template</p>
  </div>

</footer>


   <script src="index.js"></script>

</body>
</html>
