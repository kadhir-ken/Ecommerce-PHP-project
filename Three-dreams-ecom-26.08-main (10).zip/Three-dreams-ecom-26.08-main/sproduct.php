<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams Ecommerce pvt.ltd</title>
    <link rel="web icon" href="E-commerce/shoppingcart img.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
</head>
<body>
    <!-- Your existing HTML content -->

    <section id="prodetails" class="section-p1">
        <div class="single-pro-image">
            <img src="E-commerce/Shirts img/sht img3.jpg" width="100%" id="MainImg" alt="">
            <!-- Thumbnail images -->
            <div class="small-img-group">
                <div class="small-img-col"><img src="E-commerce/Shirts img/sht img3.jpg" width="100%" class="small-img" alt=""></div>
                <div class="small-img-col"><img src="E-commerce/Shirts img/sht img5.jpg" width="100%" class="small-img" alt=""></div>
                <div class="small-img-col"><img src="E-commerce/Shirts img/sht img2.jpg" width="100%" class="small-img" alt=""></div>
                <div class="small-img-col"><img src="E-commerce/Shirts img/sht img1.jpg" width="100%" class="small-img" alt=""></div>
            </div>
        </div>

        <?php
        require_once "config.php";

        // Get product ID from URL
        $product_id = isset($_GET['id']) ? intval($_GET['id']) : 0;

        $sql = "SELECT * FROM products WHERE id = ?";
        $stmt = $link->prepare($sql);
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            echo "<div class='single-pro-details'>";
            echo "<h1>" . htmlspecialchars($row["name"]) . "</h1>";
            echo "<p>" . htmlspecialchars($row["description"]) . "</p>";
            echo "<strong><p>Price: $" . htmlspecialchars($row["price"]) . "</p></strong>";
            echo "<p>Category: " . htmlspecialchars($row["category"]) . "</p>";
            echo "<img src='" . htmlspecialchars($row["image"]) . "' alt='" . htmlspecialchars($row["name"]) . "' style='width:400px;'><br>";
            echo "</div>";
        } else {
            echo "<p>Product not found.</p>";
        }

        $stmt->close();
        ?>

        <div class="single-pro-details">
            <h6>Home / T-shirt</h6>
            <h4>Men's Fashion T-Shirt</h4>
            <h2>$139.00</h2> 
            <select id="size">
                <option>Select Size</option>
                <option>XL</option>
                <option>XXL</option>
                <option>Small</option>
                <option>Large</option>
            </select>
            <input type="number" id="quantity" value="1" min="1" oninput="validateQuantity()">
            <button class="normal" onclick="addToCart(<?php echo $product_id; ?>)">Add To Cart</button>
            <h4>Product Details</h4>
            <span>The Ultra Cotton T-shirt is made from a substantial 6.0 oz. per sq. yd. fabric constructed from bold 100% cotton. This classic fit preshrunk jersey knit provides unmatched comfort with each wear. Available in a range of colors.</span>
        </div>
    </section>

    <!-- Your existing HTML content -->

   
        <script>
    function validateQuantity() {
        const quantityInput = document.getElementById('quantity');
        if (quantityInput.value < 1) {
            quantityInput.value = 1;
        }
    }

    function addToCart(productId) {
        const quantity = document.getElementById('quantity').value;
        const xhr = new XMLHttpRequest();
        xhr.open('POST', 'add_to_cart.php', true);
        xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');

        xhr.onreadystatechange = function() {
            if (xhr.readyState === XMLHttpRequest.DONE) {
                if (xhr.status === 200) {
                    alert(xhr.responseText);
                } else {
                    alert('Error adding product to cart');
                }
            }
        };

        xhr.send('product_id=' + encodeURIComponent(productId) + '&quantity=' + encodeURIComponent(quantity));
    }
</script>

    </script>
</body>
</html>
