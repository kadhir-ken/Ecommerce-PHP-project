<?php
require_once "config.php";

// Retrieve filter values from the URL parameters
$countryFilter = isset($_GET['country']) ? strval($_GET['country']) : '';
$categoryFilter = isset($_GET['category']) ? $_GET['category'] : '';

// SQL query to retrieve products based on the filters
$sql = "SELECT * FROM products WHERE 1=1";
if (!empty($countryFilter)) {
    $sql .= " AND country = ?";
}
if (!empty($categoryFilter)) {
    $sql .= " AND category = ?";
}

$stmt = $link->prepare($sql);

// Bind parameters based on filters
if (!empty($countryFilter) && !empty($categoryFilter)) {
    $stmt->bind_param("ss", $countryFilter, $categoryFilter);
} elseif (!empty($countryFilter)) {
    $stmt->bind_param("s", $countryFilter);
} elseif (!empty($categoryFilter)) {
    $stmt->bind_param("s", $categoryFilter);
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
  
    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount']=$cartItemCount; 
    $stmt->close();
}
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Filtered Products</title>
    <link rel="stylesheet" href="index.css">
    <style>
        /* Add your styles here */
        .product-list {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
        }
        .product-item {
            border: 1px solid #ddd;
            padding: 10px;
            border-radius: 8px;
            text-align: center;
        }
        .product-item img {
            max-width: 100%;
            height: auto;
            border-radius: 8px;
        }
        #country{
            display:none;
        }
    </style>
</head>
<body>
<section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
        <div>
            <ul id="navbar-1">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a class="active" href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>
                
            </ul>
            <ul id="navbar"> 
           <a href="#" id="close"><i class="fa fa-times"></i></a>

           <a href="#" id="home-close"><i class="fa fa-times"></i></a>
        
          
           <ul id="navbar"> 
             <!-- <li id="lg-bag"><a><i class="fa fa-shopping-bag" ></i></a></li> -->
             <!-- <li><a class="active" href="index.php">Home</a></li>
             <li><a href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li> 
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li> -->
             <a href="#" id="close"><i class="fa fa-times"></i></a>


             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
             <div>
               <div id="user-info">
          <?php if (isset($_SESSION['user_name'])): ?>
              <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
              
        
             
          <?php endif; ?>
      </div>
                  <?php 
                  if (isset($_SESSION['user_name'])){
                      echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                  }else{
                      echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                 echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

              echo "<br><a id='help' href='#'>help?</a>";
                  }?>
              </div>
           </div>
              
            </ul><br>
              

            <!-- Mobile Navigation -->
            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
            </ul>
        </div>
        <div id="home-nav"> 
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php  echo $cartItemCount; ?></span>
            </a>      
            <i id="home-bar" class="fas fa-outdent"></i>
        </div>
      
        <div id="mobile">
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php echo $cartItemCount; ?></span>
            </a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
        
    </section>
    <h1>Products from <?php echo htmlspecialchars($countryFilter ?: 'All Countries'); ?> in <?php echo htmlspecialchars($categoryFilter ?: 'All Categories'); ?></h1>
    
    <section id="filter-section">
        <!-- Country and Category Filter Form -->
        <form method="get" id="filter-form">
            <!-- <label for="country">Select Country:</label> -->
            <select name="country" id="country">
                <option value="">All Countries</option>
                <option value="India" <?php echo $countryFilter == 'India' ? 'selected' : ''; ?>>India</option>
                <option value="China" <?php echo $countryFilter == 'China' ? 'selected' : ''; ?>>China</option>
                <option value="Vietnam" <?php echo $countryFilter == 'Vietnam' ? 'selected' : ''; ?>>Vietnam</option>
            </select>
            
            <label for="category">Select Category:</label>
            <select name="category" id="category">
                <label>select your category</label> 
                <option value="">All Categories</option>

            <option value="Household Items" <?php echo $categoryFilter == 'Household Items' ? 'selected' : ''; ?>>Household Items</option>
            <option value="Electronics"<?php echo $categoryFilter == 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
            <option value="Clothes"<?php echo $categoryFilter == 'Clothes' ? 'selected' : ''; ?>>Clothes</option>
            <option value="Fashion Accessories"<?php echo $categoryFilter == 'Fashion Accessories' ? 'selected' : ''; ?>>Fashion Accessories</option>
            <option value="Stationery"<?php echo $categoryFilter == 'Stationery' ? 'selected' : ''; ?>>Stationery</option>
    
            <option value="Skin and Hair care products"<?php echo $categoryFilter == 'Skin and Hair care products' ? 'selected' : ''; ?>>Skin and Hair care products</option>
            <option value="Cosmetics"<?php echo $categoryFilter == 'Cosmetics' ? 'selected' : ''; ?>>Cosmetics</option>
            <option value="Pet Accessories"<?php echo $categoryFilter == 'Pet Accessories' ? 'selected' : ''; ?>>Pet Accessories</option>
            <option value="Art & Crafts works"<?php echo $categoryFilter == 'Art & Crafts works' ? 'selected' : ''; ?>>Art & Crafts works</option>
            <option value="Gifts"<?php echo $categoryFilter == 'Gifts' ? 'selected' : ''; ?>>Gifts</option>
            <option value="Toys"<?php echo $categoryFilter == 'Toys' ? 'selected' : ''; ?>>Toys</option>
            <option value="Sports"<?php echo $categoryFilter == 'Sports' ? 'selected' : ''; ?>>Sports</option>
            <option value="Handmade products"<?php echo $categoryFilter == 'Handmade products' ? 'selected' : ''; ?>>Handmade products</option>
            <option value="Baby products"<?php echo $categoryFilter == 'Baby products' ? 'selected' : ''; ?>>Baby products</option>
            <option value="Sports"<?php echo $categoryFilter == 'Education' ? 'selected' : ''; ?>>Education</option>
            </select>
            
            <input type="submit" value="Filter">
        </form>
    </section>
    
    <section id="product1" class="section-p1">
                 <h2>Filtered Products</h2>
                <div class="pro-container">
                    <?php
                   if ($result->num_rows > 0) {
                       while ($row = $result->fetch_assoc()) {
                        echo "<div class='pro'>";
                        echo"<h2><a href='sproduct.php?id=" . urlencode($row["id"]) . "'></h2>";
                        echo "<img src='" . $row["image"] . "' alt='" . $row["name"] . "' style='width:200px;'><br>";
                        echo "<h2>" . $row["name"] . "</h2>";
                        echo "<p>Brand: " . $row["brand"] . "</p>";
                        echo "<p>Category: " . $row["category"] . "</p>";
                        echo "<p>Country: " . $row["country"] . "</p>";
                        echo "<p>Price: $" . $row["price"] . "</p>";
                        echo "</div>";
                      }
                   } else {
                    echo "No products found";
                   }
    
                 
                  ?>
                </div>
            </section>
    
            <footer class="section-p1">
        <div class="col">
            <img class="logo" src="images/logo & title/new logo.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> G.S. Road, Dispur, Guwahati, Assam</p>
            <p><strong>Phone:</strong> (+91) 9860 922 922 / 6901 239 002</p>
            <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="about.php">About Us</a>
            <a href="services.php">Delivery Information</a>
            <a href="privacy.html">Privacy Policy</a>
            <a href="terms.html">Terms & Conditions</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign In</a>
            <a href="cart.html">View Cart</a>
            <a href="wishlist.html">My Wishlist</a>
            <a href="order.html">Track My Order</a>
            <a href="help.html">Help</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google Play</p>
            <div class="row">
                <img src="images/pay/app.jpg" alt="">
                <img src="images/pay/play.jpg" alt="">
            </div>
            <p>Secured Payment Gateways</p>
            <img src="images/pay/pay.png" alt="">
        </div>

        <div class="copyright">
            <p>Copyright © 2024 Three Dreams eCommerce Pvt. Ltd.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this product?')) {
                        const productId = this.getAttribute('data-id');
                        fetch('shop.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({ action: 'delete', id: productId })
                        }).then(response => response.text())
                          .then(result => {
                              alert(result);
                              location.reload(); // Reload the page to see the changes
                          });
                    }
                });
            });
        });
        
            document.getElementById('country').addEventListener('change', function() {
                document.getElementById('filter-form').submit();
            });
    
            document.getElementById('category').addEventListener('change', function() {
                document.getElementById('filter-form').submit();
            });
      
    </script>
</body>
</html>

<?php
$stmt->close();
$link->close();
?>
