<?php
// Database connection
require_once "config.php"; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';

    if (empty($email)) {
        echo '<p class="error">Email is required.</p>';
        exit;
    }

    // Check if email exists in the database
    $sql = "SELECT id FROM users1 WHERE email = ?";
    if ($stmt = $link->prepare($sql)) {
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            // Email exists, generate a password reset token
            $token = bin2hex(random_bytes(50)); // Generate a secure random token
            $stmt->close();

            // Store the token in the database with an expiration time
            $sql = "INSERT INTO password_resets (email, token, expires_at) VALUES (?, ?, NOW() + INTERVAL 1 HOUR)";
            if ($stmt = $link->prepare($sql)) {
                $stmt->bind_param("ss", $email, $token);
                $stmt->execute();

                // Send the password reset email
                $resetLink = "http://localhost/Three-dreams-ecom-26.08-main/resetpwd.php?token=" . $token;

                $subject = "Password Reset Request";
                $message = "Click the following link to reset your password: " . $resetLink;
                $headers = "From: kadhirdj@gmail.com";

                if (mail($email, $subject, $message, $headers)) {
                    echo '<p class="success">Password reset link has been sent to your email.</p>';
                } else {
                    echo '<p class="error">Error sending email.</p>';
                }
            } else {
                echo '<p class="error">Error preparing SQL statement.</p>';
            }
        } else {
            echo '<p class="error">No account found with that email.</p>';
        }
    } else {
        echo '<p class="error">Error preparing SQL statement.</p>';
    }

    $link->close();
}
?>

<!DOCTYPE html>
<head>
<title>Three Dreams eCommerce pvt.ltd</title>
<link rel="web icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" type="text/css" href="forgotpwd.css">
    <!-- <script type="text/javascript" src="js.js"></script> -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
<style> 
 
</style></head>
    <body>
    <header class="home">
         
        <div class="img" ><img src="images/logo & title/new logo.png" class="logo" alt="logo">
          </div>
          <!-- <div class="container"><div class="logo-name"><h1>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h1><center><h5>𝑩𝒓𝒊𝒅𝒈𝒊𝒏𝒈 𝑩𝒐𝒓𝒅𝒆𝒓𝒔 𝒂𝒏𝒅 𝑺𝒐𝒖𝒓𝒄𝒊𝒏𝒈 𝑺𝒖𝒄𝒄𝒆𝒔𝒔</h5></center></div>
         </div>  -->
         <div class="container"><div class="logo-name"><center><h1>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h1><h5>𝑩𝒓𝒊𝒅𝒈𝒊𝒏𝒈 𝑩𝒐𝒓𝒅𝒆𝒓𝒔 𝒂𝒏𝒅 𝑺𝒐𝒖𝒓𝒄𝒊𝒏𝒈 𝑺𝒖𝒄𝒄𝒆𝒔𝒔</h5></center></div>
        </div> 
        
         
    </header>
    <section>
     <div class="container">
    <div class="box">
    <!-- <img src="img/login and reg/user.png
    " class="user"> -->
        <h2>Reset password</h2>

        <form action="forgotpwd.php" name="myform" onsubmit="return vfun()" method="post">
            <p>Phone Number or Email ID</p>
            <div class="input-box">
            <input type="email" name="email" placeholder="Enter phone Number/email ID ">
            </div>


            <!-- <p>New Password</p>
            <input type="text" name="uname" placeholder="New Password">

            <p>Confirm Password</p>
            <input type="password" name="upswd" placeholder="Confirm Password"> -->

             <div id="errorBox"></div>
            <input type="submit" value="Send Link">
             <!-- <a href="#"><center>forget password</center></a> -->
            <br><br>
            <center><a href="register.php">Register for new account?</a></center>
             <!-- <a href="login.php">Login</a></span> -->
            
        </form>
        
    </div>
     </div>
    </section>

</body>

</html>
<!-- <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
</head>
<body>
    <form action="forgotpwd.php" method="post">
        <label for="email">Enter your email address:</label>
        <input type="email" id="email" name="email" required>
        <input type="submit" value="Send Password Reset Link">
    </form>
</body>
</html> -->
