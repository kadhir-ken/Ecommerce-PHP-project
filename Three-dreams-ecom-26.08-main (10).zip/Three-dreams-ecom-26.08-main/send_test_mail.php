<?php
$to = 'kadhirdj@gmail.com';
$subject = 'Test Email from PHP';
$message = 'This is a test email sent using XAMPP sendmail.';
$headers = 'From: kadhirdj007@gmail.com';

if (mail($to, $subject, $message, $headers)) {
    echo 'Email sent successfully';
} else {
    echo 'Failed to send email';
}
?>
