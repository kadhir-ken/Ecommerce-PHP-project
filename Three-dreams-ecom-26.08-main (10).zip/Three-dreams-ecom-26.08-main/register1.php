<?php
// Include database connection
include 'config.php';

// Start session
session_start();

// Check if form is submitted
if (isset($_POST['submit'])) {
    // Get user inputs
    $user_type = $_POST['user_type']; // Changed from 'user' to 'user_type'
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Validate inputs
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Invalid email format.";
    } else {
        // Prepare SQL statement to prevent SQL injection
        $stmt = $link->prepare("INSERT INTO admin (user, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $user_type, $email, $password);

        // Execute the query and check for success
        if ($stmt->execute()) {
            $success = "Registration successful!";
        } else {
            $error = "Error: " . $stmt->error;
        }

        // Close statement
        $stmt->close();
    }
}

// Close connection
$link->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Registration</title>
</head>
<body>
    <h1>Admin Registration</h1>
    <?php
    if (isset($error)) {
        echo "<p style='color: red;'>$error</p>";
    }
    if (isset($success)) {
        echo "<p style='color: green;'>$success</p>";
    }
    ?>
    <form action="register.php" method="post">
        <label for="user_type">User Type:</label>
        <select name="user_type" id="user_type" required>
            <option value="Admin">Admin</option>
            <option value="User">User</option>
        </select>
        <br>
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>
        <br>
        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>
        <br>
        <input type="submit" name="submit" value="Register">
    </form>
</body>
</html>
