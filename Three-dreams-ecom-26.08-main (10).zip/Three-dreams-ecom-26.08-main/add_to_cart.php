<?php
session_start();
require_once "config.php";

// Check if the user is logged in
if (!isset($_SESSION['user_id'])) {
    echo "Please log in to add items to your cart.";
    exit();
}

// Handle adding product to cart
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $user_id = $_SESSION['user_id'];
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;

    // Check if product exists
    $sql = "SELECT id FROM products WHERE id = ?";
    if ($stmt = $link->prepare($sql)) {
        $stmt->bind_param("i", $product_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            // Product exists, add to cart
            $stmt->close();

            // Check if item already exists in cart
            $sql = "SELECT id FROM cart WHERE user_id = ? AND product_id = ?";
            if ($stmt = $link->prepare($sql)) {
                $stmt->bind_param("ii", $user_id, $product_id);
                $stmt->execute();
                $stmt->store_result();

                if ($stmt->num_rows == 0) {
                    // Item is not in the cart, add it
                    $stmt->close();
                    $sql = "INSERT INTO cart (user_id, product_id, quantity) VALUES (?, ?, ?)";
                    if ($stmt = $link->prepare($sql)) {
                        $stmt->bind_param("iii", $user_id, $product_id, $quantity);

                        if ($stmt->execute()) {
                            echo "Product added to your cart!";
                        } else {
                            echo "Error adding product to cart: " . $stmt->error;
                        }
                    } else {
                        echo "Error preparing SQL statement: " . $link->error;
                    }
                } else {
                    echo "Product is already in your cart.";
                }
            } else {
                echo "Error preparing SQL statement: " . $link->error;
            }
        } else {
            echo "Product does not exist.";
        }
    } else {
        echo "Error preparing SQL statement: " . $link->error;
    }

    $link->close();
}
?>
