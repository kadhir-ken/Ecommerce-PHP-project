

<?php
// Initialize the session
session_start();
 
// // Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
//     header("location: login.php");
//     exit;
// }

//      include_once 'config.php';
      
 
// Check if the user is logged in, if not then redirect him to login page
// if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
//     header("location: login.php");
//     exit;
// }
      
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >Three Dreams eCommerce pvt.ltd</title>
    <link rel="web icon" href="images/logo & title/shoppingcart  img.jpg">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
   <style>
    .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }
   </style>
</head>
<body>
    
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
       
        <div>
            <ul id="navbar-1">

                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>

            </ul>
           

            <ul id="navbar"> 
             <!-- <li id="lg-bag"><a><i class="fa fa-shopping-bag" ></i></a></li> -->
             <!-- <li><a class="active" href="index.php">Home</a></li>
             <li><a href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li> 
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li> -->
             <a href="index.php" id="close"><i class="fa fa-times"></i></a>


             <a href="index.php" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
                 <div>
                 <div id="user-info">
            <?php if (isset($_SESSION['user_name'])): ?>
                <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                
          
               
            <?php endif; ?>
        </div>
                    <?php 
                    if (isset($_SESSION['user_name'])){
                        echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                    }else{
                        echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                   echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

                echo "<br><a id='help' href='#'>help?</a>";
                    }?>
                </div>
             </div>

              
            </ul><br>

            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.html">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                

                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <div class="container">
          
              
            <br><br>
                <br><a id="help" href="#">help?</a>
                
            </ul>





            <!-- <div class="row-1">
                <button id="login"><a href="login.php">Login</a></button>
                 <button id="signup"><a href="register.php">Sign Up</a></button>
                 <a href="#">help?</a>
               </div> -->
               

        </div>
      
        <div id="home-nav"> 
            <a href="cart.php"> <?php
               
                if (isset($_SESSION['user_id']) && isset($_SESSION['cartcount'])) {
                    $cartItemCount=$_SESSION['cartcount'];
               echo "<i class='fa fa-shopping-bag'><span class='cart-count'> $cartItemCount
                     </span></i>";}?>
        </a>      
            <i id="home-bar" class="fas fa-outdent"></i>
           
        </div>
      
        <div id="mobile">
            <a href="cart.php"><i class="fa fa-shopping-bag" ></i></a>
                <i id="bar" class="fas fa-outdent"></i><?php
                $cartItemCount=$_SESSION["cartcount"];?>
                <span class="cart-count"><?php echo $cartItemCount; ?></span>
        </div>

    </section>
    
    <!-- <section id="hero">
        <h4>Trade-in-offer</h4> 
        <h2>Super values deals</h2>
        <h1>On all products</h1>
        <p>save more with  coupons & up to 70% off!</p>
        <button><a href="shop.html">Shop Now</a></button>
    </section> -->

   <section>

    <section>
        <div id="para-1" class="section-p1">
            <h3> At Three Dreams, we don’t just talk about big dreams—we make them happen.
                 As a premier global sourcing leader, we connect the world’s top manufacturers with ambitious businesses like 
                 yours,driving your success through relentless efficiency, superior quality, and uncompromising service.</h3>

        </div>
    </section>

    <section class="section-p1">
        <div class="slider">
            <figure>
                <div class="slide">
                   <!-- <h1>Hello World</h1> -->
                   <img src="images/home/slide img/img1.jpg" alt="slide img">
                </div>
                <div class="slide">
                   <!-- <h1>Slide-1</h1> -->
                   <img src="images/home/slide img/img2.jpg" alt="slide img">
                </div>
                <div class="slide">
                   <!-- <h1>Slide-2</h1> -->
                   <img src="images/home/slide img/img3.jpg" alt="slide img">
                </div>
                <div class="slide">
                   <!-- <h1>Slide-3</h1> -->
                   <img src="images/home/slide img/img4.jpg" alt="slide img">
                </div>
              
            </figure>
         </div>
    
    
    
     </section>






    <div id="para-2" class="section-p1">
    <h3>Our Goal</h3>
    <p>Our Goal is to make it easy to do business anywhere. We do this by giving suppliers the tools necessary 
        to reach a global audience for their products, 
        and by helping buyers find products and suppliers quickly and efficiently.</p>
    
    <h3>Anytime, Anywhere</h3>
    <p>As a platform, we continue to develop services to help businesses do more and discover new opportunities.
        Whether it’s sourcing from your mobile phone or contacting suppliers in their local language, 
        turn to Three Dreams E-commerce pvt.ltd for all your global business needs.</p>
    </div>


   </section>





   <section id="feature" class="section-p1">
         <!-- <div class="fe-box">
            <img src="images/home/card img/fe img1.jpg" alt="shipping">
            <h6>Free Shipping</h6>
         </div> -->
         <div class="fe-box">
            <img src="images/home/card img/fe img2.jpg" alt="order">
            <h6>Online Order</h6>
         </div>
         <div class="fe-box">
            <img src="images/home/card img/fe img3.jpg" alt="money">
            <h6>Save Money</h6>
        </div>
        <!-- <div class="fe-box">
            <img src="images/home/card img/fe img4.jpg" alt="Promotions">
            <h6>Promotions</h6>
        </div> -->
        <div class="fe-box">
            <img src="images/home/card img/fe img5.jpg" alt="sell">
            <h6>Happy Sell</h6>
        </div>
        <div class="fe-box">
            <img src="images/home/card img/fe img6.jpg" alt="support">
            <h6>F24/7Support</h6>
        </div>

        
   </section>

   <!-- <section id="product1" class="section-p1">
    <h2>featured Products</h2>
    <p>Summer colletion New Mordern Design</p>
    <div class="pro-container">
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img1.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>cartoon Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$78</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus "></i></a>
            </div>
       
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img2.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$80</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>
            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img3.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5> cotton Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$70</h4>
                </div>
                 <a href="#"class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img4.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$90</h4>
                </div>
                 <a href="#" class="cart" ><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/watch img/watch img6.jpg" alt="">
                <div class="des">
                    <span>TATA</span>
                    <h5>Watch</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$60</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/watch img/watch img1.jpg" alt="">
                <div class="des">
                    <span>TATA</span>
                    <h5>modern Watch</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$90</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>
            
            
            <div class="pro">
                <img src="images/home/product img/watch img/watch img2.jpg" alt="">
                <div class="des">
                    <span>TATA</span>
                    <h5>Watch</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$75</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/watch img/watch img3.jpg" alt="">
                <div class="des">
                    <span>TATA</span>
                    <h5>watch</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$40</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

        </div>
     
   </section> -->

<!-- <section id="banner" class="section-m1">
    <h4>Repair Services</h4>
    <h2>Up to <span>70% off</span> All T-shirts &Accessories</h2>
    <button class="normal">Explore More</button>
    
</section> -->


<!-- <section id="product1" class="section-p1">
    <h2>New Arrivals</h2>
    <p>Summer colletion New Mordern Design</p>
    <div class="pro-container">
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img1.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>cartoon Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$78</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus "></i></a>
            </div>
       
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img2.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$90</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>
            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img4.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5> cotton Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$100</h4>
                </div>
                 <a href="#"class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img5.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$85</h4>
                </div>
                 <a href="#" class="cart" ><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img6.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$95</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img6.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$110</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>
            
            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img3.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$60</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>

            
            <div class="pro">
                <img src="images/home/product img/shirts img/sht img5.jpg" alt="">
                <div class="des">
                    <span>adidas</span>
                    <h5>modern Shirt</h5>
                    <div class="star">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                    </div>
                    <h4>$65</h4>
                </div>
                 <a href="#" class="cart"><i class="fa fa-cart-plus"></i></a>
            </div>



        </div>
     
   </section> -->

<!-- <section id="sm-banner" class="section-p1">
    <div class="banner-box">
        <h4>crazy deals</h4>
        <h2>buy 1 get 1 free</h2>
        <span>The best classic dress is on sale cara</span>
        <button class="white">Learn More</button>
    </div>
    <div class="banner-box banner-box2">
        <h4>spring/summer</h4>
        <h2>upcoming seaon</h2>
        <span>The best classic dress is on sale cara</span>
        <button class="white">collection</button>
    </div>



</section> -->

<!-- <section id="banner3">
    <div class="banner-box">
        <h2>SEASONAL SALE</h2>
       <h3>winter Collection -50% OFF</h3>
    </div>
    <div class="banner-box banner-box2">
        <h2>NEW FOOTWEAR COLLECTION</h2>
       <h3>Spring/Summer 2023</h3>
    </div>
    <div class="banner-box banner-box3">
        <h2>T-Shirts</h2>
       <h3>New Trendy Prints</h3>
    </div>
</section> -->







<section id="banner3">
    <div class="banner-box">
        <h2>our mission</h2>
       <p>Make it easy to do business anywhere.</p>
    </div>
    <div class="banner-box banner-box2">
        <h2>OUR LOCATIONS</h2>
       <p>We have teams around the world.</p>
    </div>
    <div class="banner-box banner-box3">
        <h2>OUR ESG PROMISES</h2>
       <p>Responsible technology. Sustainable future.</p>
    </div>
</section>

<!-- <section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Sign Up For Newsletters</h4>
        <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
    </div>
     <div class="form">
        <input type="text" placeholder="Your email address">
        <button class="normal">Sign Up</button>
     </div>

</section> -->


<!-- <footer class="section-p1">
      <div class="col">
        <div class="logo-icon"><img src="images/logo & title/ThreeDream logo.jpg" alt="logo img"  style="height:100px;width: 120px;">
        <h6>Three Dreams eCommerce pvt.ltd </h6></div><br>
        <h4>Contact</h4>
        <p><strong>Address:</strong> No #13/53,3rd Floor,Rams Apartment,AshokNagar,Chennai,TamilNadu,India</p>
        <p><strong>Phone:</strong>  +01  2345678/(+91) 98 765 4321</p>

        
     
       <div class="follow">
         <h4>Follow us</h4>
          <div class="icon">
              <i class="fab fa-facebook-f"></i>
              <i class="fab fa-twitter"></i>
              <i class="fab fa-instagram"></i>
              <i class="fab fa-pinterest-p"></i>
              <i class="fab fa-youtube"></i>
          </div>
       </div>
    </div>

    <div class="col">
         <h4>About</h4>
         <a href="#">About Us</a>
         <a href="#">Delivery Information</a>
         <a href="#">Privacy Policy</a>
         <a href="#">Terms & Conditions</a>
         <a href="#">Contact Us</a>
    </div>


    <div class="col">
        <h4>My Account</h4>
        <a href="#">Sign in</a>
        <a href="#">View Cart</a>
        <a href="#">My Wishlist</a>
        <a href="#">Track My Order</a>
        <a href="#">Help</a>
   </div>

    <div class="col install">
        <h4>Install App</h4>
        <p>From App Store or Google Play</p>
        <div class="row">
             <img src="images/logo & title/icon img17.jpg" alt="app store icon" style="height: 60px;width: 120px;"  >
            <img src="images/logo & title/icon img18.jpg" alt="" style="height: 60px; width: 120px;"> 
        </div>
        <p>Secure Payment Gateways</p>
         <img src="images/logo & title/pay img 1.jpg" alt="payment icon" style="height:80px; width:140px;">
    </div>

    <div class="copyright">
        <p>©2024, ThreeDreams E-commerce pvt.ltd etc- HTML CSS Ecommerce Template</p>
    </div>

</footer> -->

<footer class="section-p1">
    <div class="col">
      <div class="logo-icon"><img src="images/logo & title/ThreeDream logo.jpg" alt="logo img"  style="height:100px;width: 120px;">
      <h6>Three Dreams eCommerce pvt.ltd </h6></div><br>
      <h4>Contact</h4>
      <p><strong>Address:</strong> No #13/53 , Rams Apartment , 3rd Floor ,AshokNagar,Chennai-600 083,TamilNadu,India</p>
      <p><strong>Phone:</strong>  +91 9003472895</p>

   
     <div class="follow">
       <h4>Follow us</h4>
        <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <!-- <i class="fab fa-pinterest-p"></i>
            <i class="fab fa-youtube"></i> -->
        </div>
     </div>
  </div>

  <div class="col">
       <h4>About</h4>
       <a href="about.php">About Us</a>
       <a href="services.php">Services</a>
       <a href="shop.html">Shop</a>
       <a href="contact.php">Contact Us</a>
  </div>


  <div class="col">
      <h4>My Account</h4>
      <a href="#">Sign in</a>
      <a href="#">View Cart</a>
      <a href="#">My Wishlist</a>
      <a href="#">Track My Order</a>
      <a href="#">Help</a>
 </div>


  <div class="copyright">
      <p>©2024, ThreeDreams E-commerce pvt.ltd etc- HTML CSS Ecommerce Template</p>
  </div>

</footer>

   <script src="index.js"></script>

</body>
</html>
