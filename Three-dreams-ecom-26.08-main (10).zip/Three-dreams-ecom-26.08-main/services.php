
<?php

session_start();


?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title >Three Dreams eCommerce pvt.ltd</title>
    <link rel="web icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
     .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }
   </style>
</head>
<body>
    
    
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
       
        <div>
            <ul id="navbar-1">
                
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a class="active"  href="services.php">Services</a></li> 
                <li><a  href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>

            </ul>


            <ul id="navbar"> 
           
             <a href="#" id="close"><i class="fa fa-times"></i></a>

             <div id="row-1">
                 <div>
                 <div id="user-info">
            <?php if (isset($_SESSION['user_name'])): ?>
                <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                
          
               
            <?php endif; ?>
        </div>
                    <?php 
                    if (isset($_SESSION['user_name'])){
                        echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                    }else{
                        echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                   echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

                echo "<br><a id='help' href='#'>help?</a>";
                    }?>
                </div>
             </div>
             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
          
           
              
            </ul><br>

            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                
                <div id="row-1">
                 <div>
                 <div id="user-info">
            <?php if (isset($_SESSION['user_name'])): ?>
                <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
                
          
               
            <?php endif; ?>
        </div>
                    <?php 
                    if (isset($_SESSION['user_name'])){
                        echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                    }else{
                        echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                   echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

                echo "<br><a id='help' href='#'>help?</a>";
                    }?>
                </div>
             </div>
            </ul>

        </div>
      
        <div id="home-nav"> 
        <a href="cart.php"> <?php
               
               if (isset($_SESSION['user_id']) && isset($_SESSION['cartcount'])) {
                   $cartItemCount=$_SESSION['cartcount'];
              echo "<i class='fa fa-shopping-bag'><span class='cart-count'> $cartItemCount
                    </span></i>";}?>
       </a>      
           <i id="home-bar" class="fas fa-outdent"></i>
        </div>
      
        <div id="mobile">
            <a href="#"><i class="fa fa-shopping-bag" ></i></a>
                <i id="bar" class="fas fa-outdent"></i>
               
        </div>

    </section>
     
    
    <section id="page-header" class="about-header">
       
     
       
    </section>
   
     
   <!-- <section id="hero">
    <h4>Trade-in-offer</h4> 
    <h2>Super values deals</h2>
    <h1>On all products</h1>
    <p>save more with  coupons & up to 70% off!</p>
    <button><a href="shop.html">Shop Now</a></button>
</section> -->
    <section id="services" class="section-p1">
       
        <div class="fe-box">
           <img src="images/services/img1.jpg" alt="">
           <h6>your orders</h6>
        </div>
        <div class="fe-box">
           <img src="images/services/img2.jpg" alt="">
           <h6>Returns and Refunds</h6>
        </div>
        <div class="fe-box">
           <img src="images/services/img3.jpg" alt="">
           <h6>Manage Addresses</h6>
       </div>
       <div class="fe-box">
           <img src="images/services/img4.jpg" alt="">
           <h6>Manage Prime</h6>
       </div>
       <div class="fe-box">
           <img src="images/services/img5.jpg" alt="">
           <h6>Payment settings</h6>
       </div>
       <div class="fe-box">
           <img src="images/services/img6.jpg" alt="">
           <h6>Account settings</h6>
       </div>

       
  </section>
  

  <section class="section-p1">
    <div class="slider">
        <figure>
            <div class="slide">
               <!-- <h1>Hello World</h1> -->
               <img src="images/services/bg/slide img/img1.jpg" alt="slide img">
            </div>
            <div class="slide">
               <!-- <h1>Slide-1</h1> -->
               <img src="images/services/bg/slide img/img2.jpg" alt="slide img">
            </div>
            <div class="slide">
               <!-- <h1>Slide-2</h1> -->
               <img src="images/services/bg/slide img/img3.jpg" alt="slide img">
            </div>
            <div class="slide">
               <!-- <h1>Slide-3</h1> -->
               <img src="images/services/bg/slide img/img4.jpg" alt="slide img">
            </div>
          
        </figure>
     </div>



 </section>






<!-- <section id="newsletter" class="section-p1 section-m1">
    <div class="newstext">
        <h4>Sign Up For Newsletters</h4>
        <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
    </div>
     <div class="form">
        <input type="text" placeholder="Your email address">
        <button class="normal">Sign Up</button>
     </div>
</section> -->


<footer class="section-p1">
    <div class="col">
      <div class="logo-icon"><img src="images/logo & title/ThreeDream logo.jpg" alt="logo img"  style="height:100px;width: 120px;">
      <h6>Three Dreams eCommerce pvt.ltd </h6></div><br>
      <h4>Contact</h4>
      <p><strong>Address:</strong> No #13/53 , Rams Apartment , 3rd Floor ,AshokNagar,Chennai-600 083,TamilNadu,India</p>
      <p><strong>Phone:</strong>  +91 9003472895</p>

   
     <div class="follow">
       <h4>Follow us</h4>
        <div class="icon">
            <i class="fab fa-facebook-f"></i>
            <i class="fab fa-twitter"></i>
            <i class="fab fa-instagram"></i>
            <!-- <i class="fab fa-pinterest-p"></i>
            <i class="fab fa-youtube"></i> -->
        </div>
     </div>
  </div>

  <div class="col">
       <h4>About</h4>
       <a href="about.php">About Us</a>
       <a href="services.php">Services</a>
       <a href="shop.html">Shop</a>
       <a href="contact.php">Contact Us</a>
  </div>


  <div class="col">
      <h4>My Account</h4>
      <a href="#">Sign in</a>
      <a href="#">View Cart</a>
      <a href="#">My Wishlist</a>
      <a href="#">Track My Order</a>
      <a href="#">Help</a>
 </div>


  <div class="copyright">
      <p>©2024, ThreeDreams E-commerce pvt.ltd etc- HTML CSS Ecommerce Template</p>
  </div>

</footer>

   <script src="index.js"></script>

</body>
</html>
