<?php
ob_start(); // Start output buffering
?>


<?php
require_once "config.php";
session_start(); // Start the session to manage cart items

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = $_POST['id'];

    // Prepare and execute the delete statement
    $stmt = $link->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);

    if ($stmt->execute()) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $link->error;
    }

    $stmt->close();
    $link->close();
    exit();
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();

    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount'] = $cartItemCount; 
    $stmt->close();
}
// Filter products by country, category, or search term
$countryFilter = isset($_POST['country']) ? $_POST['country'] : '';
$categoryFilter = isset($_POST['category']) ? $_POST['category'] : '';
$searchQuery = isset($_POST['search']) ? '%' . $_POST['search'] . '%' : '';

// Retrieve filtered products based on the selected filters and search query
$sql = "SELECT * FROM products WHERE 1=1";
$params = [];
$types = '';

if (!empty($countryFilter)) {
    $sql .= " AND country = ?";
    $params[] = $countryFilter;
    $types .= 's';
}
if (!empty($categoryFilter)) {
    $sql .= " AND category = ?";
    $params[] = $categoryFilter;
    $types .= 's';
}
if (!empty($searchQuery)) {
    $sql .= " AND name LIKE ?";
    $params[] = $searchQuery;
    $types .= 's';
}

$stmt = $link->prepare($sql);

if ($stmt === false) {
    die("Error preparing the SQL statement: " . $link->error);
}

if (!empty($params)) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
        a{
            text-decoration:none;
        }

    #filter-section{
        position: relative;
        left:20%;
        
    }
    form {
        justify-content: center;
        height: 230px;
        width: 600px;
        max-width: 800px;
        margin: 20px auto;
        padding:30px 20px;
        position:relative;
        left:-650px;
        background-color: #f9f9f9;
        border:2px solid black;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        background-color: lightblue;
    }

    form h4 {
        margin-bottom: 15px;
        font-size: 20px;
        text-align: center;
        color: #333;
    }

    form input[type="text"], form textarea, form input[type="file"] {
        width: calc(100% - 24px);
        margin: 8px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 16px;
        background-color: #f5f5f5;
    }

    form input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    form input[type="submit"]:hover {
        background-color: #0056b3;
    }

    form textarea {
        height: 100px;
        resize: none;
    }

    .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }
    .china{
        width:200px;
    }
    li{
        text-decoration: none;
        display:inline-flex;
        flex-direction:row;
        padding:15px;
    }
    #category{


    }
/* Initial image style */
a img {
    transition: transform 0.3s ease; /* Smooth transition for zoom effect */
    display: block; /* Ensure image doesn’t have extra space below */
    width: 100%; /* Make sure the image fills its container */
}

/* Hover effect */
a img:hover {
    transform: scale(1.1); /* Zoom in effect */
}
select {
            -webkit-appearance: none; /* Remove default styling in WebKit browsers */
            -moz-appearance: none;    /* Remove default styling in Firefox */
            appearance: none;         /* Remove default styling in modern browsers */
            border: 1px solid #ccc;   /* Border around the select */
            border-radius: 4px;       /* Rounded corners */
            padding: 10px 15px;       /* Padding inside the select */
            font-size: 16px;          /* Font size */
            background-color: #fff;   /* Background color */
            background-image: url('path/to/arrow-icon.svg'); /* Custom arrow icon */
            background-position: right 10px center; /* Position of the custom arrow icon */
            background-repeat: no-repeat; /* Ensure the background image doesn’t repeat */
            background-size: 16px 16px; /* Size of the background image */
            width: 100%;               /* Full width */
            box-sizing: border-box;   /* Include padding and border in the element’s total width and height */
            transition: border-color 0.3s ease; /* Smooth border color transition */
        }

        /* Styling for the select when focused */
        select:focus {
            border-color: #007bff; /* Change border color on focus */
            outline: none; /* Remove default outline */
        }

        /* Optional: Styling for the select container */
        .select-container {
            position: relative; /* Positioning for the custom arrow */
            display: inline-block; /* Fit container to the select width */
        }

        .select-container::after {
            content: ''; /* Custom arrow for better styling */
            position: absolute;
            top: 50%;
            right: 15px;
            transform: translateY(-50%);
            width: 0;
            height: 0;
            border-left: 8px solid transparent;
            border-right: 8px solid transparent;
            border-top: 8px solid #333; /* Arrow color */
        }
    </style>

</head>
<body>
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
        <div>
            <ul id="navbar-1">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a class="active" href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>
                
            </ul>
            <ul id="navbar"> 
           <a href="#" id="close"><i class="fa fa-times"></i></a>

           <a href="#" id="home-close"><i class="fa fa-times"></i></a>
        
          
           <ul id="navbar"> 
             <!-- <li id="lg-bag"><a><i class="fa fa-shopping-bag" ></i></a></li> -->
             <!-- <li><a class="active" href="index.php">Home</a></li>
             <li><a href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li> 
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li> -->
             <a href="#" id="close"><i class="fa fa-times"></i></a>


             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
             <div>
               <div id="user-info">
          <?php if (isset($_SESSION['user_name'])): ?>
              <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
              
        
             
          <?php endif; ?>
      </div>
                  <?php 
                  if (isset($_SESSION['user_name'])){
                      echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                  }else{
                      echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                 echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

              echo "<br><a id='help' href='#'>help?</a>";
                  }?>
              </div>
           </div>
              
            </ul><br>
              

            <!-- Mobile Navigation -->
            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
            </ul>
        </div>
        <div id="home-nav"> 
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php  echo $cartItemCount; ?></span>
            </a>      
            <i id="home-bar" class="fas fa-outdent"></i>
        </div>
      
        <div id="mobile">
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php echo $cartItemCount; ?></span>
            </a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
        
    </section>

       <section id="page-header"> </section>

         <section id="product1" class="section-p1">
        <!-- <h2>Featured Products</h2>
        <p>Summer collection New Modern Design</p> -->
        <div class="pro-container">
        <section id="filter-section">
       <h4>Select Country</h4>
      <ul>
        <li><a href="country1.php?country=India"><img src="images/india.avif" alt="three dreams country image" class="china"><br>India</a></li>
        <li><a href="country1.php?country=China"><img src="images/china.jpg" alt="three dreams country image" class="china"><br>China</a></li>
        <li><a href="country1.php?country=Vietnam"><img src="images/vietnam.jpg" alt="three dreams country image" class="china"><br>Vietnam</a></li>
        <!-- <li><a href="country.php">All Countries</a></li> -->
      </ul>

       <!-- <h4>Select Category</h4> -->
       <ul>
        <!-- <li><a href="country.php?category=Household Items">Household Items</a></li>
        <li><a href="country.php?category=Electronics">Electronics</a></li>
        <li><a href="country.php?category=Clothes">Clothes</a></li>
        <li><a href="country.php?category=Fashion Accessories">Fashion Accessories</a></li>
        <li><a href="country.php?category=Stationery">Stationery</a></li>
        <li><a href="country.php?category=Skin and Hair care products">Skin and Hair care products</a></li>
        <li><a href="country.php?category=Cosmetics">Cosmetics</a></li>
        <li><a href="country.php?category=Pet Accessories">Pet Accessories</a></li> -->
        <!-- Add other categories as needed -->
    </ul>
 
    </section>

            <section id="filter-section" class="select container">
                <!-- Country and Category Filter Form -->
                 <br>
                 <br><br><br><br><br><br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>  <br>
                 <form method="post" id="filter-form">
                 <label for="search">Search Products:</label>
            <input type="text" name="search" id="search" value="<?php echo isset($_POST['search']) ? $_POST['search'] : ''; ?>" placeholder="Search by product name">

                <label for="country">Select Country:</label>
                <select name="country" id="country" >
                    <option value="">All Countries</option>
                    <option value="India" <?php echo $countryFilter == 'India' ? 'selected' : ''; ?>>India</option>
                    <option value="China" <?php echo $countryFilter == 'China' ? 'selected' : ''; ?>>China</option>
                    <option value="Vietnam" <?php echo $countryFilter == 'Vietnam' ? 'selected' : ''; ?>>Vietnam</option>
                </select><br><br>
   
                <label for="category">Select Category:</label>
                <select name="category" id="category" >
                    <option value="">All Categories</option>
                 
                  <option value="Household Items" <?php echo $categoryFilter == 'Household Items' ? 'selected' : ''; ?>>Household Items</option>
                  <option value="Electronics"<?php echo $categoryFilter == 'Electronics' ? 'selected' : ''; ?>>Electronics</option>
                  <option value="Clothes"<?php echo $categoryFilter == 'Clothes' ? 'selected' : ''; ?>>Clothes</option>
                  <option value="Fashion Accessories"<?php echo $categoryFilter == 'Fashion Accessories' ? 'selected' : ''; ?>>Fashion Accessories</option>
                  <option value="Stationery"<?php echo $categoryFilter == 'Stationery' ? 'selected' : ''; ?>>Stationery</option>
                  <option value="Skin and Hair care products"<?php echo $categoryFilter == 'Skin and Hair care products' ? 'selected' : ''; ?>>Skin and Hair care products</option>
                  <option value="Cosmetics"<?php echo $categoryFilter == 'Cosmetics' ? 'selected' : ''; ?>>Cosmetics</option>
                  <option value="Pet Accessories"<?php echo $categoryFilter == 'Pet Accessories' ? 'selected' : ''; ?>>Pet Accessories</option>
                  <option value="Art & Crafts works"<?php echo $categoryFilter == 'Art & Crafts works' ? 'selected' : ''; ?>>Art & Crafts works</option>
                  <option value="Gifts"<?php echo $categoryFilter == 'Gifts' ? 'selected' : ''; ?>>Gifts</option>
                  <option value="Toys"<?php echo $categoryFilter == 'Toys' ? 'selected' : ''; ?>>Toys</option>
                  <option value="Education"<?php echo $categoryFilter == 'Education' ? 'selected' : ''; ?>>Toys</option>
                  <option value="Sports"<?php echo $categoryFilter == 'Sports' ? 'selected' : ''; ?>>Sports</option>
                  <option value="Handmade products"<?php echo $categoryFilter == 'Handmade products' ? 'selected' : ''; ?>>Handmade products</option>
                  <option value="Baby products"<?php echo $categoryFilter == 'Baby products' ? 'selected' : ''; ?>>Baby products</option>
                  <option value="Sports"<?php echo $categoryFilter == 'Education' ? 'selected' : ''; ?>>Education</option>
                </select>
                <input type="submit" value="Apply Filter">
            <input type="submit" name="clear_filter" value="Clear Filter" class="clear-btn">
        </form>

        <?php
        // Handle clear filter functionality
        if (isset($_POST['clear_filter'])) {
            $countryFilter = '';
            $categoryFilter = '';
            $searchQuery = '';
            header("Location: " . $_SERVER['PHP_SELF']); // Refresh page to reset filters
            exit();
        }
        ?>
          </section>
            <br><br>
    
           <section id="product1" class="section-p1">
                 <h2>Filtered Products</h2>
                <div class="pro-container">
               
                <?php while ($product = $result->fetch_assoc()): ?>
                    <div class="pro">
                       <h2><?php echo"<h2><a href='sproduct.php?id=" . urlencode($product["id"]) . "'></h2>";?>
                        <div class="des"><?php echo "<img src='" . $product["image"] . "' >"?>
                        <h2><?php echo htmlspecialchars($product['name']); ?></h3>
                        <p><?php echo htmlspecialchars($product['description']); ?></p>
                        <h4> <?php echo htmlspecialchars($product['price']); ?></h4>
                        <p> <?php echo htmlspecialchars($product['category']); ?></p>
                        <span> <?php echo htmlspecialchars($product['brand']); ?></span></a>
                        <!-- <form method="post"> -->
                            <!-- <input type="hidden" name="id" value="<?php echo $product['id']; ?>">
                            <input type="hidden" name="action" value="delete"> -->
                            <!-- <button type="submit">Delete</button> -->
                        <!-- </form> -->
                </div>
                </div>
                <?php endwhile; ?>
                
                </div>
            </section>
      

    <section id="upload">
        <!-- <form method="post" enctype="multipart/form-data">
            <h4>Upload New Product</h4>
            <input type="text" name="name" placeholder="Product Name" required><br>
            <textarea name="description" placeholder="Description" required></textarea><br>
            <input type="text" name="price" placeholder="Price" required><br>
            <input type="text" name="category" placeholder="Category" required><br>
            <input type="text" name="brand" placeholder="Brand" required><br>
            <input type="file" name="image" required><br>
            <input type="submit" value="Upload Product">
        </form> -->
    </section>

    <footer class="section-p1">
        <div class="col">
            <img class="logo" src="images/logo & title/new logo.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> G.S. Road, Dispur, Guwahati, Assam</p>
            <p><strong>Phone:</strong> (+91) 9860 922 922 / 6901 239 002</p>
            <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="about.php">About Us</a>
            <a href="services.php">Delivery Information</a>
            <a href="privacy.html">Privacy Policy</a>
            <a href="terms.html">Terms & Conditions</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign In</a>
            <a href="cart.html">View Cart</a>
            <a href="wishlist.html">My Wishlist</a>
            <a href="order.html">Track My Order</a>
            <a href="help.html">Help</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google Play</p>
            <div class="row">
                <img src="images/pay/app.jpg" alt="">
                <img src="images/pay/play.jpg" alt="">
            </div>
            <p>Secured Payment Gateways</p>
            <img src="images/pay/pay.png" alt="">
        </div>

        <div class="copyright">
            <p>Copyright © 2024 Three Dreams eCommerce Pvt. Ltd.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this product?')) {
                        const productId = this.getAttribute('data-id');
                        fetch('shop.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({ action: 'delete', id: productId })
                        }).then(response => response.text())
                          .then(result => {
                              alert(result);
                              location.reload(); // Reload the page to see the changes
                          });
                    }
                });
            });
        });
        
      
    </script>
</body>
</html>
<?php
ob_end_flush(); // Send the buffered output
?>

