<?php
// Database connection
require_once "config.php"; // Include your database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = isset($_POST['token']) ? trim($_POST['token']) : '';
    $new_password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($token) || empty($new_password)) {
        echo "Token and new password are required.";
        exit;
    }

    // Validate the token
    $sql = "SELECT email FROM password_resets WHERE token = ? AND expires_at > NOW()";
    if ($stmt = $link->prepare($sql)) {
        $stmt->bind_param("s", $token);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows == 1) {
            $stmt->bind_result($email);
            $stmt->fetch();
            $stmt->close();

            // Update the password
            $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

            $sql = "UPDATE users1 SET password = ? WHERE email = ?";
            if ($stmt = $link->prepare($sql)) {
                $stmt->bind_param("ss", $hashed_password, $email);
                $stmt->execute();

                // Remove the reset token
                $sql = "DELETE FROM password_resets WHERE token = ?";
                if ($stmt = $link->prepare($sql)) {
                    $stmt->bind_param("s", $token);
                    $stmt->execute();
                    
                    echo "Password has been reset successfully.";
                } else {
                    echo "Error preparing SQL statement.";
                }
            } else {
                echo "Error preparing SQL statement.";
            }
        } else {
            echo "Invalid or expired token.";
        }
    } else {
        echo "Error preparing SQL statement.";
    }

    $link->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
</head>
<body>
    <form action="resetpwd.php" method="post">
        <input type="hidden" name="token" value="<?php echo htmlspecialchars($_GET['token']); ?>">
        <label for="password">New Password:</label>
        <input type="password" id="password" name="password" required>
        <input type="submit" value="Reset Password">
    </form>
</body>
</html>
