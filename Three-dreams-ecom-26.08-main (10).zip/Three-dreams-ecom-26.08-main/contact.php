<?php 
session_start();
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="web icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
    .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }
    </style>
    <!-- Include EmailJS SDK -->
    <script type="text/javascript" src="https://cdn.emailjs.com/dist/email.min.js"></script>
    <script type="text/javascript">
        (function() {
            emailjs.init("7eHeMH6VvZvZfN6eJ");
        })();
    </script>
</head>
<body>
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
       
        <div>
            <ul id="navbar-1">
                
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a  href="shop.php">Shop</a></li>          
                <li><a class="active" href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>

            </ul>

            <ul id="navbar"> 
             <a href="#" id="close"><i class="fa fa-times"></i></a>
             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
             <div>
               <div id="user-info">
          <?php if (isset($_SESSION['user_name'])): ?>
              <p >Welcome, <?php echo htmlspecialchars($_SESSION['user_name']); ?></p>
          <?php endif; ?>
      </div>
                  <?php 
                  if (isset($_SESSION['user_name'])){
                      echo "<br><button id='login'><a href='logout.php'>Logout</a></button><br>";
                  }else{
                      echo "<br><button id='login'><a href='login.php'>Login</a></button><br>";
                 echo"  <br><button id='signup'><a href='register.php'>Sign Up</a></button><br>";

              echo "<br><a id='help' href='#'>help?</a>";
                  }?>
              </div>
           </div>
            </ul><br>

            <ul id="navbar-3">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a class="active"  href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                

                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
                
            </ul>
        </div>
      
        <div id="home-nav"> 
        <a href="cart.php"> <?php
               if (isset($_SESSION['user_id']) && isset($_SESSION['cartcount'])) {
                   $cartItemCount=$_SESSION['cartcount'];
              echo "<i class='fa fa-shopping-bag'><span class='cart-count'> $cartItemCount
                    </span></i>";}?>
       </a>      
           <i id="home-bar" class="fas fa-outdent"></i>
        </div>
      
        <div id="mobile">
        <a href="cart.php"> <?php
               if (isset($_SESSION['user_id']) && isset($_SESSION['cartcount'])) {
                   $cartItemCount=$_SESSION['cartcount'];
              echo "<i class='fa fa-shopping-bag'><span class='cart-count'> $cartItemCount
                    </span></i>";}?>
       </a>      
           <i id="home-bar" class="fas fa-outdent"></i>
               
        </div>
    </section>

    <section id="page-header" class="contact-header">
       
       
    </section>

    <section id="form-details" class="section-p1">
      <form id="contact-form">
          <span>LEAVE A MESSAGE</span>
          <h2>We love to hear from you</h2>
          <input type="text" name="from_name" placeholder="Your Name" required>
          <input type="text" name="company_name" placeholder="Company Name">
          <input type="text" name="phone" placeholder="Mobile Number">
          <input type="email" name="email" placeholder="E-mail" required>
          <input type="text" name="subject" placeholder="Subject" required>
          <textarea name="message" cols="30" rows="10" placeholder="Your Message" required></textarea>
          <button type="submit" class="normal">Submit</button>
      </form>
  </section>

  <section id="contact-details" >
    <center><h1>Locations</h1></center>
    <div class="container">
      <div class="row">  
     <div> 
        <div class="row">
            <div class="map-1">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d497511.23105803586!2d79.879329657281!3d13.04798594700017!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265ea4f7d3361%3A0x6e61a70b6863d433!2sChennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1720154542948!5m2!1sen!2sin" width="450" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <h2 >India-</h2>
            <p> No #13/53 , Rams Apartment , 3rd Floor , Ashok Nagar , Chennai - 600 083</p>
          </div>
        </div>
    </div>
    <div>
        <div class="row">
            <div class="map-2">
        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d939321.3154741916!2d112.5683111542258!3d23.125490299758!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3402f895a35c2bc7%3A0xe59e075adeae415!2sGuangzhou%2C%20Guangdong%20Province%2C%20China!5e0!3m2!1sen!2sin!4v1721899817701!5m2!1sen!2sin" width="450" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            <h2 >China-</h2>
            <p>No 202, Wanbo er Rd, Nacun Town,Panyu ,Guangzhou, China 510000</p>
             </div>
        </div>
    </div>
     <div>
        <div class="row">
           <div class="map-3">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1003450.3275705299!2d106.03566945039915!3d10.75544596140221!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x317523d0a8b3c78d%3A0x154b1f3422db6cf9!2sHo%20Chi%20Minh%20City%2C%20Vietnam!5e0!3m2!1sen!2sin!4v1721899935795!5m2!1sen!2sin" width="450" height="150" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
             <h2 >Vietnam-</h2>
             <p>Group 01, Quarter 02, Go Dau Town ,Tan Thanh District, Tay Ninh Province</p>
            </div>
        </div>
    </div>
</div>
</div>
</section>


   <section id="newslatter" class="section-p1 section-m1">
        <div class="newslatter-text">
            <h4>Sign up for Newsletters</h4>
            <p>Get E-mail updates about our latest shop and <span>special offers.</span></p>
        </div>
        <div class="form">
            <input type="text" placeholder="Your email address">
            <button class="normal">Sign Up</button>
        </div>
    </section>

    <footer class="section-p1">
        <div class="col">
            <a href="index.php"><img class="footer-logo" src="images/logo & title/new logo.png" alt="logo"></a>
            <h4>Contact</h4>
            <p><strong>Address:</strong> No #13/53 , Rams Apartment , 3rd Floor , Ashok Nagar , Chennai - 600 083</p>
            <p><strong>Phone:</strong> +91 90805 70805</p>
            <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="about.php">About Us</a>
            <a href="#">Delivery Information</a>
            <a href="#">Privacy Policy</a>
            <a href="#">Terms & Conditions</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign In</a>
            <a href="cart.php">View Cart</a>
            <a href="#">My Wishlist</a>
            <a href="#">Track My Order</a>
            <a href="register.php">Help</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google Play</p>
            <div class="row">
                <img src="images/pay/app.jpg" alt="app">
                <img src="images/pay/play.jpg" alt="play">
            </div>
            <p>Secured Payment Gateways</p>
            <img src="images/pay/pay.png" alt="pay">
        </div>

        <div class="copyright">
            <p>&copy; 2023, Three Dreams eCommerce Pvt. Ltd - HTML CSS Ecommerce Template</p>
        </div>
    </footer>

    <script src="script.js"></script>
    <script>
    // Handle form submission with EmailJS
    document.getElementById('contact-form').addEventListener('submit', function(event) {
        event.preventDefault();

        emailjs.sendForm('service_c401ih1', 'template_0jswmya', this)
            .then(function() {
                alert('Message Sent Successfully!');
            }, function(error) {
                alert('Failed to send the message. Please try again later.');
            });
    });
    </script>
</body>
</html>
