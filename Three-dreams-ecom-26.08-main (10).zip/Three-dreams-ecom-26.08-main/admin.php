<?php
require_once "config.php";
session_start(); // Start the session to manage cart items

// Handle product upload
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['action'])) {
    $name = $_POST['name'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $category = $_POST['category'];
    $brand = $_POST['brand'];
    $country =$_POST['country'];

    // Handle file upload
    $target_dir = "uploads/";
    $target_file = $target_dir . basename($_FILES["image"]["name"]);
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($target_file, PATHINFO_EXTENSION));

    // Check if image file is a actual image or fake image
    $check = getimagesize($_FILES["image"]["tmp_name"]);
    if ($check !== false) {
        $uploadOk = 1;
    } else {
        echo "File is not an image.";
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allow certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.";
        $uploadOk = 0;
    }

    // Check if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["image"]["tmp_name"], $target_file)) {
            echo "The file " . htmlspecialchars(basename($_FILES["image"]["name"])) . " has been uploaded.";

            // Insert into database
            $sql = "INSERT INTO products (name, description, price, category, image, brand,country) VALUES (?, ?, ?, ?, ?, ?,?)";
            $stmt = $link->prepare($sql);
            $stmt->bind_param("sssssss", $name, $description, $price, $category, $target_file, $brand,$country);

            if ($stmt->execute()) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $stmt->error;
            }

            $stmt->close();
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }
}

// Handle product deletion
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete') {
    $productId = $_POST['id'];

    // Prepare and execute the delete statement
    $stmt = $link->prepare("DELETE FROM products WHERE id = ?");
    $stmt->bind_param("i", $productId);

    if ($stmt->execute()) {
        echo "Product deleted successfully.";
    } else {
        echo "Error deleting product: " . $link->error;
    }

    $stmt->close();
    $link->close();
    exit();
}

// Retrieve cart item count
$cartItemCount = 0;

if (isset($_SESSION['user_id'])) {
    $userId = $_SESSION['user_id'];
    $stmt = $link->prepare("SELECT COUNT(*) AS item_count FROM cart WHERE user_id = ?");
    $stmt->bind_param("i", $userId);
    $stmt->execute();
  
    $stmt->bind_result($cartItemCount);
    $stmt->fetch();
    $_SESSION['cartcount']=$cartItemCount; 
    $stmt->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Three Dreams eCommerce Pvt. Ltd</title>
    <link rel="icon" href="images/logo & title/new logo.png">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css">
    <link rel="stylesheet" href="index.css">
    <style>
        a{
            text-decoration:none;
        }
    form {
        max-width: 400px;
        margin: 20px auto;
        padding: 20px;
        background-color: #f9f9f9;
        border: 1px solid #ddd;
        border-radius: 8px;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    form h4 {
        margin-bottom: 15px;
        font-size: 20px;
        text-align: center;
        color: #333;
    }
    /* Common button style */
form input[type="submit"],
#delete {
    width: 100%;
    padding: 10px;
    margin-top: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: background-color 0.3s ease, transform 0.3s ease;
    border: none;
    border-radius: 4px;
    text-align: center;
    display: block;
}

/* Upload Product button specific style */
form input[type="submit"] {
    background-color: #007bff;
    color: white;
}

form input[type="submit"]:hover {
    background-color: #0056b3;
}

/* Delete Products button specific style */
#delete {
    background-color: #ff4d4d;
    color: white;
}

#delete:hover {
    background-color: #ff1a1a;
    transform: scale(1.05);
}

#delete:active {
    background-color: #cc0000;
    transform: scale(1);
}


    form input[type="text"], form textarea, form input[type="file"] {
        width: calc(100% - 24px);
        margin: 8px 0;
        padding: 10px;
        border: 1px solid #ddd;
        border-radius: 4px;
        font-size: 16px;
        background-color: #f5f5f5;
    }
 
    form input[type="submit"] {
        width: 100%;
        padding: 10px;
        margin-top: 10px;
        background-color: #007bff;
        color: white;
        border: none;
        border-radius: 4px;
        font-size: 16px;
        cursor: pointer;
        transition: background-color 0.3s ease;
    }

    form input[type="submit"]:hover {
        background-color: #0056b3;
    }

    form textarea {
        height: 100px;
        resize: none;
    }

    .cart-count {
        background-color: red;
        color: white;
        border-radius: 50%;
        padding: 2px 8px;
        font-size: 14px;
        vertical-align: top;
        margin-left: -10px;
    }

  
    </style>

</head>
<body>
    <section id="header">
        <a href="#"><img src="images/logo & title/new logo.png" class="logo" alt="logo"></a>
        <div class="home-logoname"><h4>𝐓𝐡𝐫𝐞𝐞 𝐃𝐫𝐞𝐚𝐦𝐬 𝐞𝐂𝐨𝐦𝐦𝐞𝐫𝐜𝐞 𝐩𝐯𝐭 𝐥𝐭𝐝</h4></div>
        <div>
            <ul id="navbar-1">
                <li><a href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a class="active" href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="close"><i class="fa fa-times"></i></a>
                
            </ul>
            <ul id="navbar"> 
           <a href="#" id="close"><i class="fa fa-times"></i></a>

           <a href="#" id="home-close"><i class="fa fa-times"></i></a>
        
          
           <ul id="navbar"> 
             <!-- <li id="lg-bag"><a><i class="fa fa-shopping-bag" ></i></a></li> -->
             <!-- <li><a class="active" href="index.php">Home</a></li>
             <li><a href="about.php">About</a></li>
             <li><a href="services.php">Services</a></li> 
             <li><a href="shop.html">Shop</a></li>          
             <li><a href="contact.php">Contact</a></li> -->
             <a href="#" id="close"><i class="fa fa-times"></i></a>


             <a href="#" id="home-close"><i class="fa fa-times"></i></a>
             <div id="row-1">
            
           </div>
              
            </ul><br>
              

            <!-- Mobile Navigation -->
            <ul id="navbar-3">
                <li><a class="active" href="index.php">Home</a></li>
                <li><a href="about.php">About</a></li>
                <li><a href="services.php">Services</a></li> 
                <li><a href="shop.php">Shop</a></li>          
                <li><a href="contact.php">Contact</a></li>
                <a href="#" id="mobile-close"><i class="fa fa-times"></i></a>
                <br><button id="login"><a href="login.php">Login</a></button><br>
                <br><button id="signup"><a href="register.php">Sign Up</a></button><br>
                <br><a id="help" href="#">help?</a>
            </ul>
        </div>
        <div id="home-nav"> 
          
        </div>
      
        <div id="mobile">
            <a href="cart.php">
                <i class="fa fa-shopping-bag"></i>
                <span class="cart-count"><?php echo $cartItemCount; ?></span>
            </a>
            <i id="bar" class="fas fa-outdent"></i>
        </div>
        
    </section>

    <section id="page-header"></section>

   
    </section>

    <section id="upload">
        <form method="post" enctype="multipart/form-data">
            <h4>Upload New Product</h4>
            <input type="text" name="name" placeholder="Product Name" required><br>
            <textarea name="description" placeholder="Description" required></textarea><br>
            <input type="text" name="price" placeholder="Price" required><br>
            <select name="category" required>
            <option value="" disabled selected>Select Category</option>
            <option value="Household Items">Household Items</option>
            <option value="Electronics">Electronics</option>
            <option value="Clothes">Clothes</option>
            <option value="Fashion Accessories">Fashion Accessories</option>
            <option value="Stationery">Stationery</option>
            <option value="Education">Education</option>
            <option value="Skin and Hair care products">Skin and Hair care products</option>
            <option value="Cosmetics">Cosmetics</option>
            <option value="Pet Accessories">Pet Accessories</option>
            <option value="Art & Crafts works">Art & Crafts works</option>
            <option value="Gifts">Gifts</option>
            <option value="Toys">Toys</option>
            <option value="Sports">Sports</option>
            <option value="Handmade products">Handmade products</option>
            <option value="Baby products">Baby products</option>
            <option value="Sports">Education</option>
        </select><br>
       <select name="country" required>
        <option value="India">India</option>
        <option value="China">China</option>
        <option value="Vietnam">Vietnam</option>
       </select>
            <input type="text" name="brand" placeholder="Brand" required><br>
            <input type="file" name="image" required><br>
            <a href="deleteproduct.php"  id="delete">Delete Products</a>
            <input type="submit" value="Upload Product">
          
        </form>
        
    </section>

    <footer class="section-p1">
        <div class="col">
            <img class="logo" src="images/logo & title/new logo.png" alt="">
            <h4>Contact</h4>
            <p><strong>Address:</strong> G.S. Road, Dispur, Guwahati, Assam</p>
            <p><strong>Phone:</strong> (+91) 9860 922 922 / 6901 239 002</p>
            <p><strong>Hours:</strong> 10:00 - 18:00, Mon - Sat</p>
            <div class="follow">
                <h4>Follow us</h4>
                <div class="icon">
                    <i class="fab fa-facebook-f"></i>
                    <i class="fab fa-twitter"></i>
                    <i class="fab fa-instagram"></i>
                    <i class="fab fa-youtube"></i>
                </div>
            </div>
        </div>

        <div class="col">
            <h4>About</h4>
            <a href="about.php">About Us</a>
            <a href="services.php">Delivery Information</a>
            <a href="privacy.html">Privacy Policy</a>
            <a href="terms.html">Terms & Conditions</a>
            <a href="contact.php">Contact Us</a>
        </div>

        <div class="col">
            <h4>My Account</h4>
            <a href="login.php">Sign In</a>
            <a href="cart.html">View Cart</a>
            <a href="wishlist.html">My Wishlist</a>
            <a href="order.html">Track My Order</a>
            <a href="help.html">Help</a>
        </div>

        <div class="col install">
            <h4>Install App</h4>
            <p>From App Store or Google Play</p>
            <div class="row">
                <img src="images/pay/app.jpg" alt="">
                <img src="images/pay/play.jpg" alt="">
            </div>
            <p>Secured Payment Gateways</p>
            <img src="images/pay/pay.png" alt="">
        </div>

        <div class="copyright">
            <p>Copyright © 2024 Three Dreams eCommerce Pvt. Ltd.</p>
        </div>
    </footer>

    <script>
        document.addEventListener('DOMContentLoaded', () => {
            document.querySelectorAll('.delete-btn').forEach(button => {
                button.addEventListener('click', function() {
                    if (confirm('Are you sure you want to delete this product?')) {
                        const productId = this.getAttribute('data-id');
                        fetch('shop.php', {
                            method: 'POST',
                            headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                            body: new URLSearchParams({ action: 'delete', id: productId })
                        }).then(response => response.text())
                          .then(result => {
                              alert(result);
                              location.reload(); // Reload the page to see the changes
                          });
                    }
                });
            });
        });
    </script>
</body>
</html>
